<?php
session_start();
include_once "view/function.php";
$db = new db();

if (isset($_GET['page'])) {
  $id = $_GET['page'];
} else {
  $id = "home";
}
if (isset($_GET['id'])) {
  $id = $_GET['id'];
} else {
  $id = "id";
}
if (!isset($_SESSION['admin']) AND !isset($_SESSION['root']) AND !isset($_SESSION['user'])) {
	include 'view/cek.php';
}	else {
  include 'view/user.php';
}
?>