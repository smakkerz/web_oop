<div class="footer" style="clear:both">
	<center>
		Koperasi ADM &copy; copyright <?php $v=date("Y"); echo $v ?> ADM Version PROTO 1 || E-mail : YUSUFADHI77@GMAIL.COM
	</center>
</div>
