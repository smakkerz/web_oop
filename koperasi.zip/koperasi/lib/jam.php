<div class="row">
		<?php
			error_reporting(0);
			date_default_timezone_set('Asia/Jakarta');
			$tanggal= mktime(date("m"),date("d"),date("Y"));
			$jam = mktime(date('h'),date('i'));
			$hour = date("h: i", $jam);

     		$tgl1 = date("d-m-Y", $tanggal);
      		$tgl = date("d-m", $tanggal);
      		$time = date("hi", $jam);
      		$order = $_SESSION['id']."$time";
 			if ($_SESSION['id']) {

 			} else {
      	?>
			<button class="btn btn-primary" disabled="disabled" style="background-color: #000;color: #fff;"><h2><b> JAM 
			<?php
			echo $hour ?></b></h2></button><div class="pull-right"><span>
			<button class="btn btn-warning" disabled="disabled" style="background-color: #0993ff; color: #FCEC3E;"><b><strong><h4>TANGGAL 
			<?php
			echo $tgl   ?> </h4></b></strong></button></span></b>
</div>
</div>
<?php } ?>