Koperasi ADM � copyright ADM Version PROTO 1 || E-mail : YUSUFADHI77@GMAIL.COM
Sistem Informasi Penjualan dengan konsep dasar E-commerce
3 Pengguna sistem
1. Root (Username : root@root.com || sandi : admin)
2. Admin (Username : admin@admin.com || sandi : admin)
3. User (Username : user@user.com || sandi : user)

Pada Folder "lib" berisi file-file yang dibutuhkan folder "view"
dan Folder "root" berisi data untuk memproses permintaan seperti CUD(Create, Update, Delete)
	Folder "root/model" berisi layout untuk tampilan root dan admin
Folder "view" berisi data untuk menampilkan 
	Folder "view/adm" berisi menampilkan data khusus user

Spesifikasi 
OS Windows/ LINUX/ MAC
*Saran saya menggunakan XAMPP/LAMPP
PHP versi 5.6
MARIA DB versi 10.1
Browser Chrome/Chromium 45.5 keatas
Firefox versi 2015
IE Not rekomendasi
