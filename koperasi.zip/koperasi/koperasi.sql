-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 21 Jul 2016 pada 03.46
-- Versi Server: 5.5.27
-- Versi PHP: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `koperasi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_brg` int(5) NOT NULL AUTO_INCREMENT,
  `kode_brg` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis` char(20) NOT NULL,
  `stock` tinyint(4) NOT NULL,
  `harga` double NOT NULL,
  `harga_jual` double NOT NULL,
  `hari` tinyint(4) NOT NULL,
  `id_bln` tinyint(4) NOT NULL,
  `thn` smallint(6) NOT NULL,
  PRIMARY KEY (`id_brg`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_brg`, `kode_brg`, `nama`, `jenis`, `stock`, `harga`, `harga_jual`, `hari`, `id_bln`, `thn`) VALUES
(1, 'BADM0001', 'Le Minerale', 'Air mineral', 3, 21400, 22800, 8, 6, 2016),
(2, 'BADM0004', 'Indomie Goreng', 'Sembako', 4, 22000, 25000, 14, 5, 2016),
(3, 'BADM0002', 'Beras Lele Super', 'Sembako', 3, 68900, 75000, 2, 5, 2016),
(5, 'BADM0003', 'Aqua', 'Air mineral', 8, 18900, 22800, 26, 5, 2016),
(6, 'BADM0005', 'Mie Sedaap', 'Sembako', 10, 24000, 28500, 15, 7, 2016),
(7, 'BADM0006', 'Aqua 240 ml', 'Sembako', 10, 17500, 18300, 6, 7, 2016);

-- --------------------------------------------------------

--
-- Struktur dari tabel `bulan`
--

CREATE TABLE IF NOT EXISTS `bulan` (
  `id_bln` int(2) NOT NULL AUTO_INCREMENT,
  `bln` varchar(15) NOT NULL,
  PRIMARY KEY (`id_bln`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data untuk tabel `bulan`
--

INSERT INTO `bulan` (`id_bln`, `bln`) VALUES
(1, 'Januari'),
(2, 'Februari'),
(3, 'Maret'),
(4, 'April'),
(5, 'Mei'),
(6, 'Juni'),
(7, 'Juli'),
(8, 'Agustus'),
(9, 'September'),
(10, 'Oktober'),
(11, 'November'),
(12, 'Desember');

-- --------------------------------------------------------

--
-- Struktur dari tabel `day`
--

CREATE TABLE IF NOT EXISTS `day` (
  `id_hari` int(1) NOT NULL,
  `hari` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `day`
--

INSERT INTO `day` (`id_hari`, `hari`) VALUES
(1, 'Senin'),
(2, 'Selasa'),
(3, 'Rabu'),
(4, 'Kamis'),
(5, 'Jum''at'),
(6, 'Sabtu'),
(7, 'Minggu');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail`
--

CREATE TABLE IF NOT EXISTS `detail` (
  `id_usr` int(4) NOT NULL AUTO_INCREMENT,
  `id_bln` int(2) NOT NULL,
  `thn` int(4) NOT NULL,
  PRIMARY KEY (`id_usr`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `detail`
--

INSERT INTO `detail` (`id_usr`, `id_bln`, `thn`) VALUES
(1, 2, 2015),
(2, 2, 2015),
(3, 3, 2015),
(4, 8, 2015),
(5, 6, 2016);

-- --------------------------------------------------------

--
-- Struktur dari tabel `detailtransaksi`
--

CREATE TABLE IF NOT EXISTS `detailtransaksi` (
  `no_transaksi` varchar(15) NOT NULL,
  `tgl` int(2) NOT NULL,
  `id_hari` int(1) NOT NULL,
  `id_bln` int(2) NOT NULL,
  `tahun` int(4) NOT NULL,
  `pembayaran` varchar(50) NOT NULL,
  `metode` varchar(50) NOT NULL,
  `total` double NOT NULL,
  `id_status` int(1) NOT NULL,
  `id_usr` int(4) NOT NULL,
  PRIMARY KEY (`no_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detailtransaksi`
--

INSERT INTO `detailtransaksi` (`no_transaksi`, `tgl`, `id_hari`, `id_bln`, `tahun`, `pembayaran`, `metode`, `total`, `id_status`, `id_usr`) VALUES
('301200001', 15, 3, 6, 2016, 'Cash/Cod', 'Antar Barang', 97800, 5, 3),
('411140004', 20, 3, 7, 2016, 'Transfer Bank', 'Antar Barang', 189000, 1, 4),
('412470004', 5, 2, 7, 2016, 'Transfer Bank', 'Antar Barang', 97800, 5, 4),
('502360002', 19, 7, 6, 2016, 'Transfer Bank', 'Ambil Barang', 102600, 5, 5),
('504320003', 30, 4, 6, 2016, 'Transfer Bank', 'Antar Barang', 97800, 5, 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gmbr_rekening`
--

CREATE TABLE IF NOT EXISTS `gmbr_rekening` (
  `Rekening` varchar(10) NOT NULL,
  `gambar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gmbr_rekening`
--

INSERT INTO `gmbr_rekening` (`Rekening`, `gambar`) VALUES
('BCA', 'lib/galeri/BCA.png'),
('BNI', 'lib/galeri/bni.png'),
('MANDIRI', 'lib/galeri/mandiri.png'),
('BRI', 'lib/galeri/bri.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `panel`
--

CREATE TABLE IF NOT EXISTS `panel` (
  `id_status` int(1) NOT NULL,
  `panel` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `panel`
--

INSERT INTO `panel` (`id_status`, `panel`) VALUES
(1, 'default'),
(2, 'warning'),
(3, 'info'),
(4, 'success'),
(5, 'success');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemasukan_lain`
--

CREATE TABLE IF NOT EXISTS `pemasukan_lain` (
  `id_masuklain` int(5) NOT NULL AUTO_INCREMENT,
  `kode` varchar(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tgl` tinyint(4) NOT NULL,
  `id_bln` tinyint(4) NOT NULL,
  `tahun` int(6) NOT NULL,
  `ket` varchar(50) NOT NULL,
  `nominal` double NOT NULL,
  `id_usr` smallint(6) NOT NULL,
  PRIMARY KEY (`id_masuklain`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `pemasukan_lain`
--

INSERT INTO `pemasukan_lain` (`id_masuklain`, `kode`, `nama`, `tgl`, `id_bln`, `tahun`, `ket`, `nominal`, `id_usr`) VALUES
(1, 'MADM0010', 'Kas Anggota', 17, 4, 2016, '260 Anggota', 8200000, 2),
(2, 'MADM0002', 'Pembayaran PDAM', 6, 6, 2016, 'laba/keuntungan', 320000, 2),
(3, 'MADM0009', 'Pinjaman', 25, 4, 2016, '-', 750000, 2),
(4, 'MADM0003', 'Pembayaran Listrik', 25, 4, 2016, 'laba/keuntungan', 54100, 2),
(5, 'MADM0004', 'Pembayaran Listrik', 25, 5, 2016, 'laba/keuntungan', 541000, 2),
(6, 'MADM0005', 'Pembayaran PDAM', 7, 5, 2016, 'laba/keuntungan', 320000, 2),
(7, 'MADM0006', 'Kas Anggota', 18, 5, 2016, ' 155 Anggota ', 5000000, 2),
(9, 'MADM0007', 'Event Bazar', 19, 5, 2016, 'Laba/keuntungan', 5000000, 2),
(10, 'MADM0001', 'Pinjaman', 26, 5, 2016, '-', 900000, 2),
(11, 'MADM0011', 'Pembayaran PDAM', 6, 4, 2016, 'laba/keuntungan', 32500, 2),
(12, 'MADM0012', 'Simpanan Pokok Anggota', 16, 6, 2016, '-', 7000000, 2),
(13, 'MADM0013', 'Pembayaran Rekening telepon', 11, 5, 2016, '-', 450000, 2),
(14, 'MADM0014', 'Penjualan bulan April', 10, 5, 2016, 'Laba/keuntungan hasil penjualan', 456900, 2),
(15, 'MADM0015', 'Hibah Amanah Daarul Muttaqin', 2, 7, 2016, 'bantuan dari pihak yayasan', 52800000, 2),
(16, 'MADM0016', 'MUDHARABAH', 11, 6, 2016, '-', 36040000, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengeluaran`
--

CREATE TABLE IF NOT EXISTS `pengeluaran` (
  `id_keluar` int(5) NOT NULL AUTO_INCREMENT,
  `kode` varchar(10) NOT NULL,
  `nama` text NOT NULL,
  `nominal` double NOT NULL,
  `ket` text NOT NULL,
  `tgl` varchar(10) NOT NULL,
  `id_bln` tinyint(4) NOT NULL,
  `tahun` int(6) NOT NULL,
  `id_usr` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_keluar`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `pengeluaran`
--

INSERT INTO `pengeluaran` (`id_keluar`, `kode`, `nama`, `nominal`, `ket`, `tgl`, `id_bln`, `tahun`, `id_usr`) VALUES
(4, 'KADM0002', 'Membayar air dan lain-lain', 150000, '-', '25', 4, 2016, 2),
(5, 'KADM0003', 'Membayar listrik', 50000, '-', '25', 4, 2016, 2),
(6, 'KADM0010', 'Pinjaman', 450000, '-', '26', 5, 2016, 2),
(7, 'KADM0007', 'Pembayaran Musyarakah', 6667000, 'INVENTARIS', '18', 6, 2016, 2),
(8, 'KADM0005', 'Pembiayaan Murabahah', 20500000, '-', '18', 6, 2016, 2),
(9, 'KADM0004', 'Pembayaran Musyarakah', 3667000, 'INVENTARIS', '10', 5, 2016, 2),
(10, 'KADM0009', 'Pinjaman', 9500000, '-', '26', 4, 2016, 2),
(11, 'KADM0003', 'Membayar listrik', 89000, '-', '12', 5, 2016, 2),
(12, 'KADM0002', 'Membayar air dan lain-lain', 190000, '-', '12', 5, 2016, 2),
(13, 'KADM0001', 'Membayar gaji karyawan', 2100000, '2 karyawan', '20', 5, 2016, 2),
(14, 'KADM0008', 'Membayar gaji karyawan+THR', 4000000, '2 Karyawan+THR', '2', 7, 2016, 2),
(15, 'KADM0002', 'Membayar air dan lain-lain', 196000, '-', '2', 7, 2016, 2),
(16, 'KADM0011', 'Pinjaman', 100000, '-', '15', 7, 2016, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengendali`
--

CREATE TABLE IF NOT EXISTS `pengendali` (
  `id_usr` int(3) NOT NULL AUTO_INCREMENT,
  `status` varchar(20) NOT NULL,
  `user` varchar(20) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `level` enum('root','admin','user','') NOT NULL,
  `almt` varchar(50) NOT NULL,
  `foto` varchar(255) NOT NULL,
  PRIMARY KEY (`id_usr`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data untuk tabel `pengendali`
--

INSERT INTO `pengendali` (`id_usr`, `status`, `user`, `pass`, `level`, `almt`, `foto`) VALUES
(1, 'KETUA KOPERASI', 'root@root.com', '21232f297a57a5a743894a0e4a801fc3', 'root', 'Jl Sidomukti 5 Tlogosari Semarang ', 'lib/galeri/kop.jpg'),
(2, 'admin KOPERASI ADM', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'Jl. Sidomukti 4 tlogosari Semarang', 'lib/galeri/user.png'),
(3, 'Pengguna', 'user@user.com', 'ee11cbb19052e40b07aac0ca060c23ee', 'user', 'Jl. Sidomukti 4 tlogosari Semarang jawa tengah', 'lib/galeri/nopic.jpg'),
(4, 'Pengguna 2', 'user2@user.com', '7e58d63b60197ceb55a1c487989a3720', 'user', 'Jl. Tlogosari raya Semarang', 'lib/galeri/user.png'),
(5, 'Ucup', 'ucup@user.com', '1e17778d0d8217b035daffba02c06054', 'user', 'Jln. Pedurungan', 'lib/galeri/user.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `posisi`
--

CREATE TABLE IF NOT EXISTS `posisi` (
  `id_status` int(2) NOT NULL,
  `Posisi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `posisi`
--

INSERT INTO `posisi` (`id_status`, `Posisi`) VALUES
(1, 'Sedang diproses oleh Admin'),
(2, 'Menunggu Konfirmasi pembayaran via Bank'),
(3, 'Sedang dikirim'),
(4, 'Siap diambil'),
(5, 'Sukses');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekening`
--

CREATE TABLE IF NOT EXISTS `rekening` (
  `Rekening` varchar(10) NOT NULL,
  `nomor` varchar(20) NOT NULL,
  `a_nama` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rekening`
--

INSERT INTO `rekening` (`Rekening`, `nomor`, `a_nama`) VALUES
('MANDIRI', '1030006055558', 'Kop Amanah Daarul Muttaqi'),
('BNI', '3700038880', 'Kop Amanah Daarul Muttaqi'),
('BRI', '1004056888', 'Kop Amanah Daarul Mut');

-- --------------------------------------------------------

--
-- Struktur dari tabel `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id_st` int(10) NOT NULL AUTO_INCREMENT,
  `catatan` text NOT NULL,
  `tgl` int(2) NOT NULL,
  `id_bln` int(2) NOT NULL,
  `tahun` int(4) NOT NULL,
  `menit` varchar(10) NOT NULL,
  `id_hari` int(1) NOT NULL,
  `id_usr` int(5) NOT NULL,
  `note` enum('bisa','lost','','') NOT NULL,
  PRIMARY KEY (`id_st`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data untuk tabel `status`
--

INSERT INTO `status` (`id_st`, `catatan`, `tgl`, `id_bln`, `tahun`, `menit`, `id_hari`, `id_usr`, `note`) VALUES
(26, 'BAGI PENGGUNA TERIMAKASIH ATAS INFORMASINYA\r\n-Ketua~~', 19, 5, 2016, '22.04 WIB', 4, 1, 'bisa'),
(28, 'kantor buka', 23, 5, 2016, '11.02 WIB', 1, 2, 'bisa'),
(30, 'Untuk acara halal bi halal akan diadakan kapan ??', 22, 6, 2016, '19.26 WIB', 3, 3, 'bisa'),
(31, 'Untuk acara halal bi halal akan diadakan 2-3 minggu setelah lebaran dengan bersamaan acara persiapan hari kemerdekaan dan rapat tahunan koperasi\r\n~~Sekian~~\r\n- Admin', 22, 6, 2016, '19.33 WIB', 3, 2, 'bisa'),
(33, 'Mohon perhatian bagi pengguna sistem,\r\nKoperasi akan tutup sementara atau libur mulai tanggal 30 Juni 2016 sampai 10 Juli 2016 guna merayakan hari raya idul fitri.\r\nUntuk transaksi dan lain-lain akan dilakukan kembali tanggal 10 Juli 2016 dan buka kembali tanggal 11 Juli 2016.\r\nSekian Terima kasih atas perhatiannya.\r\nKami segenap jajaran pihak Koperasi Amanah Daarul Muttaqin "Selamat hari raya idul fitri 1437"', 25, 6, 2016, '17.11 WIB', 6, 1, 'bisa'),
(34, 'Diberitahukan bagi semua anggota koperasi\r\nacara halal bi halal akan diadakan pada :\r\n tanggal 16 Juli 2016 hari Sabtu \r\n jam 16.00- selesai\r\n tempat di Masjid Amanah Daarul Muttaqin\r\n\r\ndan akan membahas acara hari kemerdekaan serta pembentukan panitia kemerdekaan\r\nSekian Terimakasih.\r\nSelamat mudik semoga selamat sampai tujuan.\r\n~~Ketua Koperasi~~', 2, 7, 2016, '13.36 WIB', 6, 1, 'bisa'),
(35, 'toko buka', 15, 7, 2016, '08.29 WIB', 5, 2, 'bisa'),
(36, 'Test', 21, 7, 2016, '08.45 WIB', 4, 3, 'bisa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE IF NOT EXISTS `transaksi` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `no_transaksi` int(16) NOT NULL,
  `kode_brg` varchar(15) NOT NULL,
  `beli` tinyint(4) NOT NULL,
  `subtotal` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id`, `no_transaksi`, `kode_brg`, `beli`, `subtotal`) VALUES
(10, 301200001, 'BADM0002', 1, 75000),
(11, 301200001, 'BADM0003', 1, 22800),
(14, 502360002, 'BADM0001', 2, 45600),
(15, 502360002, 'BADM0005', 2, 57000),
(16, 504320003, 'BADM0003', 1, 22800),
(17, 504320003, 'BADM0002', 1, 75000),
(28, 412470004, 'BADM0002', 1, 75000),
(29, 412470004, 'BADM0001', 1, 22800),
(30, 411140004, 'BADM0002', 1, 75000),
(31, 411140004, 'BADM0003', 5, 114000);

--
-- Trigger `transaksi`
--
DROP TRIGGER IF EXISTS `hapus`;
DELIMITER //
CREATE TRIGGER `hapus` AFTER DELETE ON `transaksi`
 FOR EACH ROW BEGIN
	UPDATE barang SET stock=stock+OLD.beli
    	WHERE kode_brg=OLD.kode_brg;
END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `transaksi`;
DELIMITER //
CREATE TRIGGER `transaksi` AFTER INSERT ON `transaksi`
 FOR EACH ROW BEGIN
		UPDATE barang SET stock=stock-NEW.beli
        	WHERE kode_brg=NEW.kode_brg;
END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `waktu`
--

CREATE TABLE IF NOT EXISTS `waktu` (
  `no_transaksi` int(20) NOT NULL,
  `waktu` varchar(20) NOT NULL,
  PRIMARY KEY (`no_transaksi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `waktu`
--

INSERT INTO `waktu` (`no_transaksi`, `waktu`) VALUES
(301200001, '1-2 Hari'),
(301510004, '14 Juli 2016'),
(403160004, '14 Juli 2016'),
(411140004, '22 Juli 2016'),
(412470004, '15 Juli 2016'),
(502360002, 'Senin, 20 Juni 2016'),
(504320003, '11 Juli 2016'),
(506500004, '1 Hari kerja');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
