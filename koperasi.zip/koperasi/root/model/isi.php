	<?php 

  if (isset($_GET['id'])) {
        if ($_GET['id']==1) {
            echo "<div class='alert alert-info alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil Disimpan.</strong></div>";
        } elseif ($_GET['id']==2) {
            echo "<div class='alert alert-danger alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil menghapus Catatan</strong></div>";
        } elseif ($_GET['id']==3) {
            echo "<div class='alert alert-info alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil menambahkan Data</strong></div>";
        } elseif ($_GET['id']==4) {
            echo "<div class='alert alert-danger'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Data tidak boleh kosong.</strong></div>";
        } elseif ($_GET['id']==5) {
            echo "<div class='alert alert-success'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Data berhasil diubah.</strong></div>";
        } 
    }
  if (isset($_GET['hapus'])) {
        if ($_GET['hapus']==1) {
            echo "<div class='alert alert-info alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil Dihapus. </strong></div>";
        } elseif ($_GET['hapus']==2) {
            echo "<div class='alert alert-danger alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil menghapus Data</strong></div>";
        } 
      }
	?>
<div class="tab-content" id="myTabContent">
	<div class="tab-pane fade in active" id="home">
		<div class="alert alert-danger alert-dismissable">
		  <button type="button" class="close" data-dismiss="alert" aria-hidden="true"> &times; </button> 
			<h2><img src="lib/galeri/hi.png" width="60px"> Selamat Datang <b>
				<?php echo "$name </b></h2><h3>Berita terkini tentang KOPERASI AMANAH DA'ARUL MUTTAQIN</h3>"; ?>
		</div> 
      <h3 class="text-primary">Catatan Terbaru</h3>
		<?php
$array=$db->tampil_Data();
?> 
</div>
   		<?php 
   		include "view/stock.php";
   		include "view/pemasukan.php";
   		include "view/pengguna.php";
   		?>
