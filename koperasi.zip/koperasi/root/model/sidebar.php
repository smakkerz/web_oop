<p style="background-color: #d00;font-size: 18px;"><center>
   <a href="index.php" class="btn btn-primary" 
   style="background-color: #ee0022;border-radius: 25px 25px; font-color: #fff; border-size: 25px ; border-color: #000;">
	<?php date_default_timezone_set('Asia/Jakarta');
			$jam = mktime(date('h'),date('i'),date('s'));
			$hour = date(" h: i ", $jam);
			
			echo "<h2 style='background-color: #fff; color: #000;''>". $hour ."</h2>"; ?> WIB</a></center><p class="aktif">
      Tab Aktif : <b class="text-primary" style="font-size: 15px;"><span></span></b></p></p>
 <ul class="nav nav-pills nav-stacked" id="myTab">
  <li class="active"><a href="#home" data-toggle="tab"><h4><img src="lib/galeri/format.png" width="35px"> Home</h4></a></li>
   <li><a href="#status" data-toggle="tab" ><h4><img src="lib/galeri/User-Group.png" width="35px"> Catatan</h4></a></li> 
   <li><a href="#transaksi" data-toggle="tab" ><h4><img src="lib/galeri/tran.png" width="35px"> Transaksi</h4></a></li> 
   <li><a href="#stock" data-toggle="tab"><h4><img src="lib/galeri/palet.png" width="38px"> Stock Barang</h4></a></li> 
   <li><a href="#pengeluaran" data-toggle="tab"><h4><img src="lib/galeri/cart-icon.png" width="35px"> Pengeluaran</h4></a></li> 
   <li><a href="#pemasukan" data-toggle="tab"><h4><img src="lib/galeri/cal.png" width="35px"> Pemasukan</h4></a></li> 
   <li><?php 
   if (isset($_SESSION['root'])) { 
   	echo"<li><a href='#lap' data-toggle='tab' ><h4><img src='lib/galeri/format.png' width='37px'> Laporan</h4></a></li>";
  } else { }
?>
   <li><a href="#pengguna" data-toggle="tab"><h4><img src="lib/galeri/user.png" width="31px"> Pengguna</h4></a>
     <li><a href="#petunjuk" data-toggle="tab"><h4><img src="lib/galeri/book.png" width="35px"> Petunjuk Penggunaan</h4></a>
   </li><center><a class='pull-left' data-target='#myModal2' data-toggle='modal' href='#'> 
<img src="<?php echo $foto ?>" width="53%" class="img-rounded"></center></a>
        <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModallabel" aria-hidden="true">
          <div  class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header" style="background-color: #d00;color: #fff;">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
              <h4 class="modal-title" id="myModalLabel" >
                Koperasi Amanah Daarul Muttaqin<span class="pull-right">Upload Foto</span>
              </h4>
            </div>
            <div class="modal-body">
            <form enctype="multipart/form-data" method="post" action="./root/proses.php">
                      <input type="hidden" name="user" value="<?php echo $id; ?>">
                        <input type="file" accept="image/JPEG" class="btn btn-danger" name="foto">Ukuran Gambar/Foto maksimal 1,5 Mb
                  <span class="pull-right"><button type="submit" name="upload" class="btn btn-primary">
                  <img src="lib/galeri/save.png" width="24px"> Upload</button></span>
            </form>
          </div>
        </div>
      </div>
</div>
<script>
  $(function() {
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
      var aktif = $(e.target).text();
      $(".aktif span").html(aktif);
    });
  });
</script>