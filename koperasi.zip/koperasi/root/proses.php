<?php
session_start();
date_default_timezone_set('Asia/Jakarta');
include_once "../view/function.php";

  $db = new db();
//Autenfikasi Login serta pembagian tampilan
if (isset($_POST['login'])) {
	$user = mysqli_real_escape_string($db, $_POST['user']);
	$pass = md5(mysqli_escape_string($db, $_POST['pass']));

	$sql = "SELECT * FROM pengendali WHERE user='$user' AND pass='$pass'";
	$query = $db->query($sql);
	$hitung = $query->num_rows;
	if ($hitung!==0) {
		$ambil = $query->fetch_assoc();
		extract($ambil);
		if ($level=='admin') {
			$_SESSION['admin']=$user;
			$_SESSION['id']=$id_usr;
			header("Location:../");
		} elseif($level=='user') {
			$_SESSION['user']=$user;
			$_SESSION['id']=$id_usr;
			header("location:../view/adm/admin.php");
		} elseif ($level=='root') {
			$_SESSION['root']=$user;
			$_SESSION['id']=$id_usr;
			header("Location:../");
		}
		
	}else{
		header("location:../index.php?log=1000");
	}
}
elseif (isset($_GET['logout'])) {
	session_destroy();
	
}
elseif (isset($_POST['tambah_rekening'])) {
$no = $_POST['nomor'];
$nama = $_POST['nama'];
$bank = $_POST['bank'];
 if ($bank=="" ) {
    header("location:../index.php?id=4");
  }else {
$sql = "INSERT INTO rekening (rekening,
nomor,
a_nama) VALUES (?,
?,
?)";
if ($stmt = $db->prepare($sql)) {
  $stmt->bind_param(
    "sss", $bank, $no, $nama
    );
  if ($stmt->execute()) {
    header("location: ../index.php?id=3");
      }
    }
  }
}
elseif (isset($_POST['waktu'])) {
  $no = $_POST['no_tran'];
  $waktu = $_POST['estimasi'];
    $sql = "INSERT INTO Waktu (no_transaksi,
    waktu) VALUES (?,
    ?);";
    $stmt = $db->prepare($sql);
    $stmt->bind_param(
      "is", $no, $waktu );
    if($stmt->execute()) {
      header("location:../index.php?id=1");
    } else {
      header("location:../index.php?id=2");
    }
}
//Menambahkan status/catatan 
   elseif (isset($_POST['simpan_note'])) {
    if ($catatan !== "") {
    $id_usr = $_SESSION['id'];
    $catatan = $_POST['note']; //mysqli_real_escape_string($db, );
    $id_st = "NULL";
    $note = "bisa";
    $tgl = date("Y");
    $day = date("N");
    $bulan = date("m");
    $hari = date("d");
    $men = date("H.i"). " WIB";
    $sql= "INSERT INTO status (id_st,
      catatan,
      tgl,
      id_bln,
      tahun,
      menit,
      id_hari,
      id_usr,
      note) VALUES (?,
      ?,
      ?,
      ?,
      ?,
      ?,
      ?,
      ?,
      ?)";
    if ($statement = $db->prepare($sql)) {
      $statement->bind_param(
        "isiiisiis", $id_st, $catatan, $hari, $bulan, $tgl, $men, $day, $id_usr, $note
        );
      if ($statement->execute()) {
        if (isset($_SESSION['user'])) {
          header("location:../view/adm/admin.php?id=1");
          }else{        
        header("location:../index.php?id=1");
      }
        $statement->close();
      } else {
        header("location:../index.php#ganote&id=4");
      }
    }else {
      header("location:../index.php#gagal&id=4");
    }
}
} //Menambahkan stock barang khusus untuk admin
  elseif (isset($_POST['simpan_brg'])) {

  $id = "NULL";
  $kode = $_POST['kode'];
  $nama     = $_POST['nama'];
  $jenis   = $_POST['jenis'];
  $no = $_POST['jmlh'];
  $harga = $_POST['harga'];
  $status  = $_POST['total'];
  $tgl = date("Y");
  $bulan = date("m");
  $hari = date("d");

    $sql= "INSERT INTO barang (id_brg, 
      kode_brg, 
      nama, 
      jenis, 
      stock,
      harga, 
      harga_jual,
      hari, 
      id_bln,
      thn) VALUES (?, 
      ?,
      ?,
      ?, 
      ?, 
      ?, 
      ?, 
      ?, 
      ?, 
      ?)";
    if ($statement = $db->prepare($sql)) {
      $statement->bind_param(
        "isssiddiii", $id, $kode, $nama, $jenis, $no, $harga, $status, $hari, $bulan, $tgl
        );
      if ($statement->execute()) {
        header("location:../index.php?id=1");
        $statement->close();
      } else {
        header("location: ../index.php#garang?status=2");
      }
    } else {
      header("location: ../index.php#gagalbrg?status=2");
    }
}
elseif (isset($_POST['anggota'])) {
  $id = "NULL";
  $nama = $_POST['nama'];
  $alamat = $_POST['alamat'];
  $sandi = $_POST['sandi'];
  $user = $_POST['email'];
  $level = $_POST['level'];
  $foto = "lib/galeri/user.png";
  $bln = date("m");
  $thn = date("Y");

  $sql = "INSERT INTO pengendali (id_usr,
  status,
  user,
  pass,
  level,
  almt,
  foto) VALUES (?,
  ?,
  ?,
  ?,
  ?,
  ?,
  ?)";
  $sql1 = "INSERT INTO detail (id_usr,
  id_bln,
  thn) VALUES (?,
  ?,
  ?)";
  $stmt = $db->prepare($sql);
  $stmt->bind_param(
    "issssss", $id, $nama, $user, md5($sandi), $level, $alamat, $foto
    );
  $stmt->execute();
    $stmt->close();
    $exe = $db->prepare($sql1);
    $exe->bind_param(
      "iii", $id, $bln, $thn
      );
    if($exe->execute()) {
      header("location: ../index.php?id=3");
      $exe->close();
    } else {
      header("location: ../index.php?id=4");
    }
}
//Penambahan data untuk sumber pemasukan lain
  elseif (isset($_POST['masukan'])) {
    if (!isset($_SESSION['admin'])){
      header("location: ../index.php");
    } else {
  $user = $_SESSION['id'];
  $id = "NULL";
  $kode = $_POST['id_masuk'];
  $nama     =  $_POST['nama'];
  $nominal   =  $_POST['nominal'];
  $keterangan =  $_POST['lain'];
  $tgl = date("Y");
  $bulan = date("m");
  $hari = date("d");

    $sql= "INSERT INTO pemasukan_lain (id_masuklain, 
      kode, 
      nama, 
      tgl, 
      id_bln,
      tahun, 
      ket,
      nominal,
      id_usr) VALUES (?, 
      ?, 
      ?, 
      ?, 
      ?, 
      ?, 
      ?,
      ?, 
      ?)";
    if ($statement = $db->prepare($sql)) {
      $statement->bind_param(
        "issiiisdi", $id, $kode, $nama, $hari, $bulan, $tgl, $keterangan, $nominal, $user
        );
      if ($statement->execute()) {
        header("location:../index.php?id=3");
        $statement->close();
      } else {
        header("location: ../index.php#errorlain?id=4");
      }
    } else {
      header("location: ../index.php#gagalmasukan?id=4");
    }
  }
} // Menambah data belanja
elseif (isset($_GET['aksi'])) {
  $user = $_SESSION['id'];
  $hari = date("N");
  $bln = date("m");
  $tgl = date("d");
  $thn = date("Y");
  $pembayaran = $_POST['pembayaran'];
  $metode = $_POST['metode'];
  $total = $_POST['total'];
  $status = "1";
  $order = $_POST['id_transaksi'];
  if ( $metode === "" || $pembayaran === "") {
      header("location: ..//view/adm/admin.php?id=4");
  } else {
  $sql = "INSERT INTO detailtransaksi(no_transaksi,
          tgl,
          id_hari,
          id_bln,
          tahun,
          pembayaran,
          metode,
          total,
          id_status,
          id_usr) VALUES (?,
          ?,
          ?,
          ?,
          ?,
          ?,
          ?,
          ?,
          ?,
          ?)";
        
            foreach($_SESSION["products"] as $product){ //Cetak setiap item, kuantitas dan harga.
        $product_qty = $product["product_qty"];
        $product_price = $product["product_price"];
        $product_code = $product["product_code"];
        $order1 = $_POST['id_transaksi'];
        $id = "NULL";
        $Harga = ($product_price * $product_qty);
          $qry = "INSERT INTO transaksi(id,
          no_transaksi,
          kode_brg,
          beli,
          subtotal) VALUES (?,
          ?,
          ?,
          ?,
          ?)";
          $stmt1 = $db->prepare($qry);
            $stmt1->bind_param(
              "issid", $id, $order1, $product_code, $product_qty, $Harga
              );
            if ($stmt1->execute()) {
              $stmt1->close();
              }
            }
            if ($statement = $db->prepare($sql)) {
            $statement->bind_param(
             "iiiiissdii", $order, $tgl, $hari, $bln, $thn, $pembayaran, $metode, $total, $status, $user
              );
            if ($statement->execute()) {
              header("location: ../view/adm/admin.php?id=1");
              unset($_SESSION['products']);
              $statement->close();
                } else {
                header("location: ../view/adm/admin.php#gagal?id=4");
                }
              } else {
              header("location: ../view/adm/admin.php?id=3");
            } 
          }
}
// Menambah data untuk data pengeluaran
  elseif (isset($_POST['keluaran'])) {
    if (!isset($_SESSION['admin'])){
      header("location: ../index.php");
    } else {
  $user = $_SESSION['id'];
  $id = "NULL";
  $kode = $_POST['kode'];
  $nama     =  $_POST['nama'];
  $nominal   =  $_POST['nominal'];
  $keterangan = $_POST['lain'];
  $tgl = date("Y");
  $bulan = date("m");
  $hari = date("d");

    $sql= "INSERT INTO pengeluaran (id_keluar, 
      kode, 
      nama, 
      nominal, 
      ket,
      tgl, 
      id_bln,
      tahun,
      id_usr) VALUES (?, 
      ?,
      ?, 
      ?, 
      ?, 
      ?, 
      ?, 
      ?, 
      ?)";
    if ($statement = $db->prepare($sql)) {
      $statement->bind_param(
        "issdsiiii", $id, $kode, $nama, $nominal, $keterangan, $hari, $bulan, $tgl, $user
        );
      if ($statement->execute()) {
        header("location:../index.php?id=3");
        $statement->close();
      } else {
        header("location: ../index.php#errorlain?id=4");
      }
    } else {
      header("location: ../index.php#gagalmasukan?id=4");
    }
  }
} 
//hapus data pada pemasukan_lain
//
// Zona Hapus
/////////////////////////////////////
elseif (isset($_GET['masuk'])) {
  if(!isset($_SESSION['admin'])) {
    header("location: ../view/logout.php");
  } else {
  $id = mysqli_real_escape_string($db, $_GET['masuk']);
  $sq = "DELETE FROM pemasukan_lain where id_masuklain=?";
  if ($stmt= $db->prepare($sq)) {
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
 // untuk response ya saya menggunakan array agar bisa menjadi JSON
  $response = array(
   'error'=>false,
   'pesan'=>'Data berhasil di hapus'
  );

  // rubah bentuk array ke format JSON
  echo json_encode($response);
    } else {
      header("location: ../index.php#error?id=4");
    }
  } else {
    header("location: ../index.php#gagal&id=4");
  }
}
}
elseif (isset($_GET['keluar'])) {
  if(!isset($_SESSION['admin'])) {
    header("location: ../view/logout.php");
  } else {
  $id = mysqli_real_escape_string($db, $_GET['keluar']);
  $sq = "DELETE FROM pengeluaran WHERE id_keluar=?";
  if ($stmt= $db->prepare($sq)) {
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        // untuk response ya saya menggunakan array agar bisa menjadi JSON
  $response = array(
   'error'=>false,
   'pesan'=>'Data berhasil di hapus'
  );

  // rubah bentuk array ke format JSON
  echo json_encode($response);
    } else {
      header("location: ../index.php#error?id=4");
    }
  } else {
    header("location: ../index.php#gagal&id=4");
  }
}
}
elseif (isset($_GET['del_brg'])) {
  if(!isset($_SESSION['admin'])) {
header("location: ../index.php?");
  } else {
  $id = mysqli_real_escape_string($db, $_GET['del_brg']);
  $sql_d = "DELETE FROM barang WHERE id_brg=?";
  if ($stmt= $db->prepare($sql_d)) {
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
  // untuk response ya saya menggunakan array agar bisa menjadi JSON
  $response = array(
   'error'=>false,
   'pesan'=>'Data berhasil di hapus'
  );

  // rubah bentuk array ke format JSON
  echo json_encode($response);
    } else {
      header("location:../index.php#gapus?id=4");
    }
  } else {
    header("location:../index.php#gagal?id=4");
  }
}
}
elseif (isset($_GET['del_id'])) {
  $id = mysqli_real_escape_string($db, $_GET['del_id']);
  $sql = "DELETE FROM pengendali WHERE id_usr=?";
  $stmt = $con->prepare($sql);
  if ($dtmt->execute()) {
    $response = array(
      'error'=>false,
      'pesan'=>'Data berhasil dihapus'
      );
      echo_json_encode($response);
    } else {
      header("location: ../index.php?id=4");
    } 
}
elseif (isset($_GET['del_status'])) {
  $id = mysqli_real_escape_string($db, $_GET['del_status']);
  $sql_d = "DELETE FROM status WHERE id_st=? ";
  if ($stmt= $db->prepare($sql_d)) {
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        // untuk response ya saya menggunakan array agar bisa menjadi JSON
  $response = array(
   'error'=>false,
   'pesan'=>'Data berhasil di hapus'
  );

  // rubah bentuk array ke format JSON
  echo json_encode($response);
    } else {
      header("location:../index.php?id=4");
    }
  } else {
    header("location:../index.php#gapuss?id=4");
  }
}
elseif (isset($_GET['del_rek'])) {
  $nomor = mysqli_real_escape_string($db, $_GET['del_rek']);
  $sql = "DELETE FROM rekening WHERE nomor=? ";
  if ($stmt = $db->prepare($sql)) {
    $stmt->bind_param("s", $nomor);
    if ($stmt->execute()) {
      header("location: ../index.php?hapus=2");
    } else {
      header("location:../index.php?id=4");
    }
  } else {
    header("location:../index.php#gagal");
  }
}
//
//ZONA HAPUS
////////////////////////
elseif (isset($_POST['ubah'])) {
  $id = mysqli_real_escape_string($db, $_POST['id_user']);
  $nama = mysqli_real_escape_string($db, $_POST['nama']);
  //$pwd = mysqli_real_escape_string($db, sha1($_POST['pwd_cek']));
  $mail = mysqli_real_escape_string($db, $_POST['email']);
  $almt = mysqli_real_escape_string($db, $_POST['alamat']);

  $sql_detail = "UPDATE pengendali SET status=?, user=?, almt=? WHERE id_usr='$id'";
  if ($nama==="" || $id==="" || $mail==="" || $almt==="") {
    header("location:../siswa&id=$id&st=4");
  }else {
    if ($statement= $db->prepare($sql_detail)) {
        $statement->bind_param(
          "sss", $nama, $mail, $almt
          );
        if ($statement->execute()) {
          header("location:../index.php?id=5");
        } else {
          header("location:../index.php&id=4");
        }
      } else {
        header("location:../index.php&id=4");
      }
    $db->close();
    
  }
}
//
//                                                     ///
//  Proses verifikasi dan konfirmasi transaksi barang //
///////////////////////////////////////////////////////
elseif(isset($_GET['data'])) {
    $no = mysqli_real_escape_string($db, $_GET['id']);
    $posisi = mysqli_real_escape_string($db, $_GET['data']);
    if($posisi=="batal") {
      $sql = "DELETE FROM detailtransaksi WHERE no_transaksi=?";
      $query = "DELETE FROM transaksi WHERE no_transaksi=?";
      $hapus = $db->prepare($sql);
        $hapus->bind_param("i", $no );
       if($hapus->execute()) {
        $hapus1 = $db->prepare($query);
          $hapus1->bind_param("i", $no );
            $hapus1->execute();
          header("location:../index.php?hapus=1");
          } else {
            header("location: ../index.php?id=4");
          } $db->close();
    } else {
    $sql = "UPDATE detailtransaksi SET id_status=? WHERE no_transaksi='$no'";
    $transaksi = $db->prepare($sql);
      $transaksi->bind_param(
        "i", $posisi );
      if($transaksi->execute()) {
        header("location: ../index.php?id=1");
      } else {
        header("location: ../index.php?id=3");
      } $db->close();
    }
} /////
////
elseif (isset($_POST['ubah_sandi'])) {
  $id = mysqli_real_escape_string($db, $_POST['id_user']);
  $pwd = md5(mysqli_real_escape_string($db, $_POST['sandi']));
  $pwd1 = md5(mysqli_real_escape_string($db, $_POST['sandi1']));
  if (!empty($pwd1) || !empty($pwd) || !empty($id)) {
  if($pwd !== $pwd1) {
        header("location:../index.php?id=$id-st5");
      } else {
    $updt = "UPDATE pengendali SET pass=? WHERE id_usr='$id'";
      if($statement = $db->prepare($updt)) {
        $statement->bind_param(
          "s", $pwd );
        if ($statement->execute()) {
           header("location:../index.php?pswd=$id&st=5");
        } else {
          header("location:../index.php&id$id&st=2");
        }
      } else {
        header("location:../index.php&a=$id&st=2");
      }
    }
  } else {
        header("location:../index.php&a=$id&st=2");
      }
}
elseif (isset($_POST['ubah_brg'])) {
    if (!isset($_SESSION['admin'])) {
    header("location:../index.php");
  }else{
  $id = mysqli_real_escape_string($db, $_POST['id_brg']);
  $nama = mysqli_real_escape_string($db, $_POST['nama']);
  $jenis = mysqli_real_escape_string($db, $_POST['jenis']);
  $stock = mysqli_real_escape_string($db, $_POST['stock']);
  $harga = mysqli_real_escape_string($db, $_POST['harga']);
  $harga_jual =  $_POST['harga_jual'];
  $tgl = date("d");
  $bln = date("m");
  $thn = date("Y");

  $sql_detail = "UPDATE barang SET nama=?, jenis=?, stock=?, harga=?, harga_jual=?, hari=?, id_bln=?, thn=? WHERE id_brg='$id'";
   if($nama==="" || $jenis==="" || $stock==="" || $harga==="" || $harga_jual===""){
    header("location: ../index.php?gagal");
   } else {
   if ($statement= $db->prepare($sql_detail)) {
        $statement->bind_param(
          "ssiddiii", $nama, $jenis, $stock, $harga, $harga_jual, $tgl, $bln, $thn
          );
        if ($statement->execute()) {
          header("location:../index.php?id=5");
        } else {
          header("location:../index.php#galbahrang&id=4");
        }
      } else {
        header("location:../index.php#gagal&id=4");
      }
    //$conn->close(); 
  }
  }
}
elseif (isset($_POST['upload'])) {
$user= $_SESSION['id'];
$foto1 = @$_FILES['foto']['name'];
$gambar = @$_FILES['foto']['tmp_name'];
$asli = $_FILES['foto']['size'];
$ukuran = 1500000;
$data = "lib/galeri/$foto1";

if ($asli < $ukuran) {
if(isset($_SESSION['user'])) {
  $move = move_uploaded_file($gambar, './../lib/galeri/'.$foto1);
    if($move) {
      $sql = "UPDATE pengendali SET foto=? WHERE id_usr='$user'";
        $oke = $db->prepare($sql);
          $oke->bind_param (
                "s", $data );
                if ($oke->execute()) {
                    header("location:../view/adm/admin.php?id=1");
                    } else {
                    header("location: ../view/adm/admin.php#error");
                    }
              }
      } else {
  $move = move_uploaded_file($gambar, '../lib/galeri/'.$foto1);
    if($move) {
      $sql = "UPDATE pengendali SET foto=? WHERE id_usr='$user'";
        $oke = $db->prepare($sql);
          $oke->bind_param (
                "s", $data );
                if ($oke->execute()) {
                    header("location:../index.php?id=1");
                    } else {
                    header("location: ../index.php#error");
                    }
                } 
      } 
    } else {

    }
}
elseif (isset($_POST['ubah_msk'])) {
  $id = mysqli_real_escape_string($db, $_POST['id_masuk']);
  $kode = mysqli_real_escape_string($db, $_POST['kode']);
  $nama = mysqli_real_escape_string($db, $_POST['nama']);
  $user = mysqli_real_escape_string($db, $_SESSION['id']);
  $jmlh = mysqli_real_escape_string($db, $_POST['nominal']);
  $ket = mysqli_real_escape_string($db, $_POST['ket']);
  $tgl = date("d");
  $bln = date("m");
  $thn = date("Y");
  $sql = "UPDATE pemasukan_lain SET nama=?, tgl=?, id_bln=?, tahun=?, ket=?, nominal=?, id_usr=? WHERE id_masuklain='$id'";
  if ($nama==="" || $jmlh==="" || $ket==="") {
    header("location: ../view/logout.php");
  } else {
      if($statement = $db->prepare($sql)) {
        $statement->bind_param (
          "siiisdi", $nama, $tgl, $bln, $thn, $ket, $jmlh, $user
           );
        if ($statement->execute()) {
           header("location:../index.php?id=5");
        } else {
          header("location:../index.php&id_siswa=$id&st=2");
        }
      } else {
        header("location:../index.php&id_siswa=$id&st=2");
      }
    $db->close();
        }
      }
elseif (isset($_POST['ubah_keluar']) || isset($_GET['kode'])) {
  $kode = mysqli_real_escape_string($db, $_POST['id_keluar']);
  $id = mysqli_real_escape_string($db, $_POST['no_keluar']);
  $nama = mysqli_real_escape_string($db, $_POST['nama_keluar']);
  $user = mysqli_real_escape_string($db, $_SESSION['id']);
  $jmlh = mysqli_real_escape_string($db, $_POST['jmlh_keluar']);
  $ket = mysqli_real_escape_string($db, $_POST['ket_keluar']);
  $tgl = date("d");
  $bln = date("m");
  $thn = date("Y");
  $sql1 = "UPDATE pengeluaran SET nama=?, nominal=?, ket=?, tgl=?, id_bln=?, tahun=?, id_usr=? WHERE id_keluar='$kode'";
  if ($nama==="" || $jmlh==="" || $ket==="") {
    header("location: ../view/logout/php");
  } else {
      if($statement = $db->prepare($sql1)) {
        $statement->bind_param (
          "sdsiiii", $nama, $jmlh, $ket, $tgl, $bln, $thn, $user
           );
        if ($statement->execute()) {
           header("location:../index.php?id=5");
        } else {
          header("location:../index.php&id_siswa=$id&st=2");
        }
      } else {
        header("location:../index.php&id_siswa=$id&st=2");
      }
    $db->close();
        }
      }
       else {
  echo "<script>window.alert('Waaahh.. Bandel ya !! ');window.location=('../');</script>";
}

?>