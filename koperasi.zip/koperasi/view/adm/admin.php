<?php
session_start();
include_once "../function.php";
include_once "../../lib/jam.php";

$db = new db();

	if(isset($_SESSION['id'])){
		$sql = "SELECT*FROM pengendali WHERE id_usr='$_SESSION[id]'";
	    $query = $db->query($sql);
		$get_user=$query->fetch_assoc();
		$name = $get_user['status'];
    $foto = $get_user['foto'];
    $id_user = $get_user['id_usr'];
	}else{
		header("Location: ../../index.php");
	}

?>
<!DOCTYPE html>

<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><s!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>E-JUAL</title>
	<link rel="icon" href="../favicon.ico" />
		<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0" name="viewport">
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" href="../../lib/asset/css/bootstrap.css" type="text/css"/>
	<link rel="stylesheet" href="../../lib/asset/css/style.css" type="text/css"/>

	<script type="text/javascript" src="../../lib/asset/js/jquery.min.js"></script>
	<script type="text/javascript" src="../../lib/asset/js/bootstrap.js"></script>
</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" style="background: -webkit-linear-gradient(-9deg, #d00, #f9a); background-color: #d02;" role="navigation">
		<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#example-navbar-collapse">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"><img src="../../lib/galeri/icon-dashboard.png"  width="40px"></span>>
		</button>
	<a href="?refresh" class="navbar-brand" title="Silahkan merefresh disini" style="color: #fff;">
							KOPERASI AMANAH DA'ARUL MUTTAQIN </a></div>
			<div class="collapsenavbar-collapse" id="example-navbar-collapse">
				<ul class="nav navbar-nav">
					<li><a href="#transaksi" style="color:#fff;font-family:  Serif;"  data-toggle="tab">
						<img src="../../lib/galeri/cart-icon.png" width="20px"> E-JUAL</a></li>
					<li><a href="#status" style="color:#fff;font-family: Serif;" data-toggle="tab" >
						<img src="../../lib/galeri/User-Group.png" width="20px"> CATATAN</a></li>
					<li><a href="#"></a></li>
					<li><a href="#cart" class="cart-box" id="cart-info" title="View Cart">
              <?php 
                if(isset($_SESSION["products"])){
                    echo count($_SESSION["products"]); 
                    }else{
                    echo 0; 
                    }
              ?>
        </a>
          </li>
					<li>
                        <a href=""></a>
                    </li>
                    <li>
                        <a href=""></a>
                    </li>
                    <li>
                      <a href=""></a>
                    </li>
                    <li><a href="#pesanan" data-toggle="tab" style="color: #fff;">
                    <span class="badge pull-right" id="jumlah"><?php $hit=$db->jmlh("$id_user", "detailtransaksi");?></span><b>Pesanan</b></a></li>
                    <li>
                      <a href="#"></a>
                        <li ><a href="#" ></a></li>
                      </li>
        </ul>
            </div>
            <!-- /.navbar-collapse -->
         <span class="pull-right" style="margin-right: 15px;padding: 10px;">
		<div class="popover-options"> 
		<a href="#" style="color: #FFF;" data-toggle="popover" data-container="body"data-content="<a href='#profil' class='btn btn-default' data-toggle='tab'>
                          <img src='../../lib/galeri/user.png' width='25px'> PROFIL</a>
                          <br class='divider'><hr>
                      <a href='../logout.php' class='btn btn-danger' >
                          <img src='../../lib/galeri/off.png' width='22px'><b> KELUAR</b></a>" data-placement="bottom">
                      <?php
                        echo"<img class='img-rounded' src='../../$foto' width='40' title='Foto $name' ><b> $name </b>";
                        ?> <span class="caret">
					</span>
				</a>
			</div>
		</span>
    <div class="shopping-cart-box">
          <a href="#cart" class="close-shopping-cart-box" > &times;</a>
      		<h3>Keranjang Belanja Anda</h3><hr>
      			<div id="shopping-cart-results">
      			</div>
    	</div>
    </nav>
        </div>
        <!-- /.container -->
					</div>	
				</div>
			</div>
<div class="container-fluid">
				<div class="alert alert-success" style="border-radius: 0px 49px;">
					<h2><img src="../../lib/galeri/hi.png" width="60px"> Selamat Datang 
					<?php echo "<b>$name</b> di E-Jual <a href='' class='text-danger' data-target='#myModal10' data-toggle='modal'>Koperasi Amanah Daarul Muttaqin</a></h2>"; 
					echo "<span class='pull-right'><strong>$tgl1</strong></span>"; ?> 
				</div>
		<?php
  		if (isset($_GET['id'])) {
       		 if ($_GET['id']==1) {
            echo "<div class='alert alert-info alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil Disimpan.</strong></div>";
       		 } elseif ($_GET['id']==2) {
            echo "<div class='alert alert-danger alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Berhasil menghapus Data</strong></div>";
        	} elseif ($_GET['id']==3) {
            echo "<div class='alert alert-info alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Mohon dipilih Metode dan pembayaran agar dapat diproses</strong></div>";
        	} elseif ($_GET['id']==4) {
            echo "<div class='alert alert-danger alert-dismissable'>
            <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            <strong>Mohon dipilih Metode dan pembayaran agar dapat diproses</strong></div>";
        		} 
   			 }
			if (isset($_GET['token'])) { //memberikan status jika tarnsaksi berhasil atau tidak
        		if ($_GET['token']==1) {
           		 echo "<div class='alert alert-info alert-dismissable'>
           		 <button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
           		 <strong>Berhasil Dihapus.</strong></div>";
        		} elseif ($_GET['token']==2) {
           		 echo "<div class='alert alert-danger alert-dismissable'>
            	<button type='button' class='close' data-dismiss='alert' aria-hidden='true'> &times; </button>
            	<strong>Berhasil menghapus Data.</strong></div>";
        			} 
      			}
			?>
      <div class="modal fade" id="myModal10" tabindex="0" role="dialog" aria-labelledby="myModallabel" aria-hidden="true">
          <div  class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header" style="background-color: #d00;color: #fff;">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
              <h4 class="modal-title" id="myModalLabel" >
                ALAMAT KOPERASI
              </h4>
            </div>
            <div class="modal-body">
              <h2><img src="../../lib/galeri/kop.jpg" width="80px"> Alamat Koperasi Amanah Daarul Muttaqin</h2><hr>
              <p>Jalan Sidomukti Raya RT 06 RW 18 (Samping Masjid Daarul Muttaqin) kelurahan Muktiharjo 
              Kidul kecamatan Pedurungan, Semarang Jawa Tengah</p>
              <iframe  src="https://www.google.com/maps/d/embed?mid=1gLk6c4LaKwK3atINOYfpt4ljb7c"
              width="550px" height="450px" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
          </div>
        </div>
      </div>
		<?php include "menu.php"; 
		?>
		</div>
<hr>
<?php
include "../../lib/footer.php";
?>
</body>
</html>
<script>
$(function ()
  { $('[data-toggle="popover"]').popover({html : true });

});
$(document).ready(function(){ 
    $(".barang-item").submit(function(e){
      var form_data = $(this).serialize();
      var button_content = $(this).find('button[type=submit]');
      button_content.html('<img src="../../lib/galeri/ajax-loader.gif"> Proses...'); //Loading button text 

      $.ajax({ //request ajax ke cart_process.php
        url: "cart_process.php",
        type: "POST",
        dataType:"json", 
        data: form_data
      }).done(function(data){ //Jika Ajax berhasil
        $("#cart-info").html(data.items); //total items di cart-info element
        button_content.html('BELI'); //
        alert("Barang telah dimasukan ke keranjang belanja anda"); 
        if($(".shopping-cart-box").css("display") == "block"){
          $(".cart-box").trigger( "click" ); 
        }
      })
      e.preventDefault();
    });

  //menampilkan item ke keranjang belanja
  $( ".cart-box").click(function(e) { 
    e.preventDefault(); 
    $(".shopping-cart-box").fadeIn(); 
    $("#shopping-cart-results").html('<img src="../../lib/galeri/ajax-loader.gif">'); //menampilkan loading gambar
    $("#shopping-cart-results" ).load( "cart_process.php", {"load_cart":"1"}); //membuat permintaan ajax menggunakan dengan jQuery Load() & update
  });
  
  //keluar keranjang belanja
  $( ".close-shopping-cart-box").click(function(e){ //fungsi klik pengguna pada keranjang belanja
    e.preventDefault(); 
    $(".shopping-cart-box").fadeOut(); //keluar keranjang belanka
  });
  
  //Menghapus item dari keranjang
  $("#shopping-cart-results").on('click', 'a.remove-item', function(e) {
    e.preventDefault(); 
    var pcode = $(this).attr("data-code"); //mendapatkan get produk
    $(this).parent().fadeOut(); //menghapus elemen item dari kotak
    $.getJSON( "cart_process.php", {"remove_code":pcode} , function(data){ //mendapatkan Harga Barang dari Server
      $("#cart-info").html(data.items); //update Menjullahkan item pada cart-info
      $(".cart-box").trigger( "click" ); //trigger click on cart-box to untuk memperbarui daftar item
    });
  });

});
</script>
  <script type="text/javascript">
function valregister(){
            if(form1.note.value==""){
                        alert("Catatan tidak boleh kosong");
                        form1.note.focus();
                        return false;
            } 
             return true; 
}
</script>
