<hr>
<div id="myTabContent" class="tab-content">
		<div class="tab-pane fade in active" id="transaksi">
	     <div class="col"><h3><span class="label label-primary">Katalog Koperasi</span>
          <span class="pull-right">
            <button style="background-color: #fff;color: #001;" disabled="disabled"><?php echo $hour ?>
            </button>
            </h3></span>
        </div>Pilih Produk Barang
          <div class="row">
            <?php
              $data_Brg=$db->brg_jual("barang");
            ?>
          </div>
    </div>
	<div class="tab-pane fade" id="status">
    	<div class="container-fluid">
      		<h3 >Status</h3>
       		<form method="post" action="../../root/proses.php" name="form3" onSubmit="return valregister()">
          		<div class="table-responsive">
              		<table class="table">
              		<tr>
                		<td style="border-top:none;">
                    		<textarea class="form-control" placeholder="Isi disini status berupa catatan,kritik,saran,penilaian,pesan,dan sebagainya untuk ditinggalkan" rows="6" name="note"></textarea>
                		</td>
              		</tr>
              		<tr>
                		<td style="border-top:none;">
                    		<button type="submit" name="simpan_note" id="save" onclick="saveForm(); return false;" class="btn btn-success">Status</button>
                		</td>
              		</tr>
              </table>
            </div>
        </form> 
		<?php 
             $user=$db->tampil_Data();
          ?>     
    </div>
  </div>
    <div class="tab-pane fade" id="pesanan">
       <h3 style="text-align:center">Pesanan Anda</h3>
          <div class="row">
            <div class="col-md-6">
              <?php
                 $pesanan=$db->tampil_pesanan("WHERE id_usr='$id_user'");
              ?>
            </div>
            <div class="col-md-6">
            <h3>Kirim Pesan</h3>
        <form method="post" action="../../root/proses.php" name="form3" onSubmit="return valregister()">
          <div class="table-responsive">
              <table class="table">
              <tr>
                <td style="border-top:none;">
                    <textarea class="form-control" placeholder="Isi disini status berupa catatan,kritik,saran,penilaian,pesan,dan sebagainya untuk ditinggalkan" rows="6" name="note"></textarea>
                </td>
              </tr>
              <tr>
                <td style="border-top:none;">
                    <button type="submit" name="simpan_note" id="save" onclick="saveForm(); return false;" class="btn btn-success">Status</button>
                </td>
              </tr>
              </table>
            </div>
        </form> <?php
                  $user=$db->tampil_Data();
              ?>
            </div>
          </div>
    </div>
    <div class="tab-pane fade" id="keranjang">
      <form action="../../root/proses.php?aksi" name="form9" method="POST">
        <h3 style="text-align:center">Review Keranjang Belanja Anda  <?php $ordo=$db->nomor("$order","no_transaksi","detailtransaksi"); ?>
          <input type="hidden" name="id_transaksi" value='<?php $ord=$db->nomor("$order","no_transaksi","detailtransaksi"); ?>'></h3>
<?php
if(isset($_SESSION["products"]) && count($_SESSION["products"])>0){
    $total          = 0;
    $user           = count( $_SESSION['products']);
    $list_tax       = '';
    $cart_box       = '<ul class="view-cart">';
    $taxes              = array( //setting pajak pengiriman
                            'Pajak (10%) :' => 10, );

    foreach($_SESSION["products"] as $product){ //Cetak setiap item, kuantitas dan harga.
        $product_name = $product["product_name"];
        $product_qty = $product["product_qty"];
        $product_price = $product["product_price"];
        $product_code = $product["product_code"];
        
        $item_price    = number_format(($product_price * $product_qty), 0);  // Harga x qty = Total harga barang
        $Harga         = ($product_price * $product_qty);
        $cart_box     .= "";
        $cart_box     .=  "
                          <li> $product_code  <p> $product_name (Qty : $product_qty | $product_price) <span>Rp. $item_price -</span></p></li>
                        <input type='hidden' name='code' value='$product_code'><input type='hidden' name='qty' value='$product_qty'>
                        <input type='hidden' name='subtotal' value='$Harga'>";
        
        $subtotal       = ($product_price * $product_qty); //Multiply  kuantitas * harga
        $total          = ($total + $subtotal); //Add up to total harga
    }
    
    $grand_total = $total;
    
    foreach($taxes as $key => $value){ //menghitung semua pajak dalam array
            $tax_amount     = round($total * ($value / 100));
            $tax_item[$key] = $tax_amount;

    }
    
    foreach($tax_item as $key => $value){ //List Pajak
        $list_tax .= $key. ' Rp. '. number_format($value, 0).' -<br />';
    }
    
    //Menampilkan pajak, biaya pengiriman & Total Belanja
    $cart_box .= "<input type='hidden' name='User' value='$user'>
    <li class=\"view-cart-total\"> $list_tax <hr>Total Belanja Anda :
    <h3 style='padding: 10px;border-radius: 20px 20px;background-color: #234;color: #FFF;'> Rp. ".number_format($grand_total, 2)." -</h3>
    </li><li><span> *Pembayaran <select name='pembayaran'><option value=''>--- Pilih ---</option>
                    <option value='Transfer Bank'>Transfer Bank</option>
                    <option value='Cash/Cod'>Cash/Cod</option></select> *Metode <select name='metode'>
                    <option value=''>--- Pilih ---</option>
                    <option value='Antar Barang'>Antar Barang </option>
                    <option value='Ambil Barang'>Ambil Barang </option></select></span></li>";    
    $cart_box .= "<li><button type='submit' class='btn btn-danger' name='kirim'><img src='../../lib/galeri/save.png' width='22px'> Kirim</button> 
                  </li><br> 
                  <span style='font-size: 12.5px;'><p> *Jika memilih Pembayaran Transfer via Bank silahkan kirim ke nomor rekening dibawah</p><p>
                  Harga Sudah termasuk PPN 10% </p>
          <p>*Untuk Metode Ambil Barang mohon tunjukkan Bukti Pembelian dan membawa Uang Cash atau Bukti Pembayaran ke Teller Koperasi</p>
          </span><input type='hidden' name='total' value='$grand_total'> </ul></form>";
    
    echo $cart_box;
    echo "<div class='row'><p>Pembayaran Transfer didukung oleh </p><img src='../../lib/galeri/Logo-Bank.png' width='185px' class='img-thumbnail'>";
    $data=$db->norek();
} else{
    echo "<h4 style='text-align:center'>Keranjang belanja anda Kosong (Coba di segarkan halaman ini untuk memastikan barang yang anda beli sudah masuk)</h4>";
}
?>
    </div>
<div class="tab-pane fade" id="profil">
  <div class="container">
	   <?php 
    $id=$db->pengguna();     
      ?>
      <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModallabel" aria-hidden="true">
          <div  class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header" style="background-color: #d00;color: #fff;">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
              <h4 class="modal-title" id="myModalLabel" >
                Koperasi Amanah Daarul Muttaqin<span class="pull-right">Upload Foto</span>
              </h4>
            </div>
            <div class="modal-body">
              <form enctype="multipart/form-data" method="post" action="../../root/proses.php">
                      <input type="hidden" name="user" value="<?php echo $id; ?>">
                        <input type="file" class="btn btn-danger" accept="image/JPEG" name="foto">Ukuran Gambar/Foto maksimal 1,5 Mb
                  <span class="pull-right"><button type="submit" name="upload" class="btn btn-primary">
                  <img src="../../lib/galeri/save.png" width="24px"> Upload</button></span>
              </form>
            </div>
          </div>
        </div>
      </div>
  </div>
</div>
