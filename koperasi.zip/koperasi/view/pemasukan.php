<div class="tab-pane fade" id="pemasukan"> 
	<div class="panel panel-primary"> 
					<div class="panel-heading"> 
						<h3 class="panel-title">Pemasukan</h3> 
					</div> 
				<div class="panel-body">
<?php
error_reporting(0);
if (isset($_SESSION['admin'])) {
?>
<div class="wrapper">
	<div class="content-view"> <!-- /form untuk menampilkan edit-->
  	<span class="label label-danger" style="font-size:18px;">Edit Data</span>
   		<span class="close-form">X</span>
  		<form class="form-horizontal" method="post" action="./root/proses.php">
   	 		<input type="hidden" name="id_masuk" id="result-no" />
        <div class="form-group">
        	<label class="col-sm-2 control-panel">Kode Pemasukan</label>
        	<div class="col-sm-4">
         		<input class="form-control" readonly="readonly" name="kode" type="text" id="result-kode">
       		</div>
      		<label class="col-sm-2 control-panel">Nama/Jenis Pemasukan</label>
      		<div class="col-sm-4">
         		<input class="form-control" name="nama" type="text" placeholder="Nama/Jenis Pemasukan" id="result-nama"  required> 
       		</div>
     	</div>
     	<div class="form-group">
      		<label class="col-sm-2 control-panel">Jumlah (Rp.)</label>
      		<div class="col-sm-4">
         		<input type="number" placeholder="Jumlah (Rp.)" id="result-jumlah" class="form-control" name="nominal"  required> 
       		</div>
   		</div>
       	<div class="form-group">
      		<label class="col-sm-2 control-panel">Keterangan</label>
      		<div class="col-sm-4">
        		<input type="text" class="form-control" id="result-ket" placeholder="Keterangan" name="ket" required> 
      		</div>
    	</div>    
          	<button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="ubah_msk">
            <img src="./lib/galeri/format.png" width="25px"> EDIT</button>
  		</form>
	</div> <!-- /form untuk menampilkan edit -->
<!-- form untuk menampilkan tambah-->
	<div class="content-form">
  		<span class="label label-primary" style="font-size:17px;">Tambah Data</span>
    		<span class="close-form">X</span>
    		<form class="form-horizontal" method="post" action="./root/proses.php" >
		  		<div class="form-group">
        			<label class="col-sm-2 control-panel">Kode Pemasukan</label>
        			<div class="col-sm-4">
         				<input class="form-control" name="id_masuk" type="text" value="<?php $no_masuk=$db->nomor('MADM','kode','pemasukan_lain'); ?>" >
       				</div>
      				<label class="col-sm-2 control-panel">Nama/Jenis Pemasukan</label>
      				<div class="col-sm-4">
         				<input class="form-control" name="nama" type="text" placeholder="Nama/Jenis Pemasukan" required> 
       				</div>
    			</div>
     			<div class="form-group">
      				<label class="col-sm-2 control-panel">Jumlah (Rp.)</label>
      				<div class="col-sm-4">
         				<input type="number" placeholder="Jumlah (Rp.)" class="form-control" name="nominal"  required> 
       				</div>
    			</div>
       			<div class="form-group">
      				<label class="col-sm-2 control-panel">Keterangan</label>
      				<div class="col-sm-4">
        				<input type="text" class="form-control"  placeholder="Keterangan" name="lain" required> 
      				</div>
    			</div>    
      				<button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="masukan" >
        			<img src="./lib/galeri/save.png" width="25px"> TAMBAHKAN</button>
			</form> 
	</div><!-- /form untuk menampilkan tambah -->
	<br>
    	<a href="#" class="control" data-set="tambah">
			<span class="label label-primary" style="font-size:19px;">Tambah Data</span>
		</a>
    	<br>
</div>
			<?php
    } else {
      ?>
	<a href="javascript:printDiv('id-elemen-yang-ingin-di-print');" class="btn btn-default">
		<img src="./lib/galeri/print.png" width="24px"> Print
	</a>
      <?php
    }
    echo "<div id='id-elemen-yang-ingin-di-print' ><div class='table-responsive'>
    <center>"; 
		if(isset($_SESSION['root'])) { 
            echo"<table class='table table-hover' style='width:98%;' border='1'>"; 
			} else {
            echo"<table class='table table-hover' style='width:98%;'>";
            }
                    echo "<thead><h2>Pemasukan</h2>
                        <tr class='info'>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Jenis Pemasukan</th>
                            <th>Tanggal</th>
                            <th>Nominal</th>
                            <th>Keterangan</th>";
                            if(isset($_SESSION['admin'])) {
                            echo"<th>Opsi</th>"; }
                        echo"</tr>
                    </thead>
                    <tbody>";
$data=$db->data('pemasukan_lain');
                    echo"</div> </div>";?>
				</div> 
			</div> 
		</div>
    <div class="tab-pane fade" id="pengeluaran"> 
  <div class="panel panel-primary"> 
      <div class="panel-heading"> 
        <h3 class="panel-title">Pengeluaran</h3> 
      </div> 
        <div class="panel-body">
<?php
if (isset($_SESSION['admin'])) {
?>
<div class="wrapper">
	<div class="content-form"> <!-- /form untuk menampilkan tambah -->
  		<span class="label label-primary" style="font-size:17px;">Tambah Data</span>
    		<span class="close-form">X</span>
   			<form class="form-horizontal" method="post" action="./root/proses.php" name="keluaran">
           	<div class="form-group">
      			<label class="col-sm-2 control-panel">Kode Pengeluaran</label>
      			<div class="col-sm-4">
         			<input class="form-control" name="kode" type="text" value="<?php $no_masu=$db->nomor('KADM','kode','pengeluaran'); ?>" required>
       			</div>
      			<label class="col-sm-2 control-panel">Nama/Jenis Pengeluaran</label>
      			<div class="col-sm-4">
         			<input class="form-control" name="nama" type="text" placeholder="Nama/Jenis Pengeluaran" required> 
       			</div>
     		</div>
     		<div class="form-group">
      			<label class="col-sm-2 control-panel">Jumlah (Rp.)</label>
      			<div class="col-sm-4">
         			<input type="number" placeholder="Jumlah (Rp.)" class="form-control" name="nominal"  required> 
       			</div>
   			</div>
       		<div class="form-group">
      			<label class="col-sm-2 control-panel">Keterangan</label>
      			<div class="col-sm-4">
        			<input type="text" class="form-control" placeholder="Keterangan" name="lain" required> 
      			</div>
    		</div>    
          		<button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="keluaran">
            	<img src="./lib/galeri/save.png" width="25px"> TAMBAHKAN</button>
        	</form>
	</div> <!-- /form untuk menampilkan tambah -->
      <br>
	<div class="content-edit"> <!-- /form untuk menampilkan  edit -->
  		<span class="label label-danger" style="font-size:20px;">Edit Data</span>
    		<span class="close-form">X</span>
      		<form class="form-horizontal" method="post" action="./root/proses.php?kode" name="ubah_data">
        		<input type="hidden" name="id_keluar" id="result-no" />
           	<div class="form-group">
            	<label class="col-sm-2 control-panel">Kode Pengeluaran</label>
                <div class="col-sm-4">
                   <input class="form-control"  id="result-kode" name="no_keluar" type="text" placeholder="Kode Pengeluaran" disabled="disabled">
                </div>
                <label class="col-sm-2 control-panel">Nama/Jenis Pengeluaran</label>
                <div class="col-sm-4">
                    <input class="form-control" name="nama_keluar" id="result-nama" type="text" placeholder="Nama/Jenis Pengeluaran" required> 
                </div>
          	</div>
          	<div class="form-group">
              	<label class="col-sm-2 control-panel">Jumlah (Rp.)</label>
                <div class="col-sm-4">
                   <input type="number" placeholder="Jumlah (Rp.)"  id="result-jumlah" class="form-control" name="jmlh_keluar"  required> 
                </div>
         	</div>
         	<div class="form-group">
             	<label class="col-sm-2 control-panel">Keterangan</label>
                <div class="col-sm-4">
                   <input type="text" class="form-control"  id="result-ket" placeholder="Keterangan" name="ket_keluar" required> 
                </div>
         	</div>    
            	<button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="ubah_keluar">
              	<img src="./lib/galeri/format.png" width="25px"> EDIT</button>
     		</form>
     <br>
	</div> <!-- /form untuk menampilkan edit -->
    <a href="#" class="control" data-set="tambah">
		<span class="label label-primary" style="font-size:19px;">Tambah Data</span>
	</a>
</div>
      <br>
<?php
    } else { ?>
	<a href="javascript:printDiv('id-elemen-2');" class="btn btn-default">
		<img src="./lib/galeri/print.png" width="24px"> Print
	</a>
    <?php } 
    echo "<div id='id-elemen-2'><div class='table-responsive'>
          <center>"; 
	if(isset($_SESSION['root'])) { 
            echo"<table class='table table-hover' style='width:98%;' border='1'>"; 
			} else {
            echo"<table class='table table-hover' style='width:98%;'>";
            }
                    echo "<thead><h2>Pengeluaran</h2>
                        <tr class='info'>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Jenis Pengeluaran</th>
                            <th>Tanggal</th>
                            <th>Nominal</th>
                            <th>Keterangan</th>";
                            if(isset($_SESSION['admin'])) {
                            echo"<th>Opsi</th>"; }
                        echo"</tr>
                    </thead>
                    <tbody>";
$file2=$db->data('pengeluaran');
                    echo"</div>";?>
                    </div>
        </div> 
  </div> 
</div>
