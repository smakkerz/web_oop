<div class="tab-pane fade" id="status"> 
  <div class="panel panel-primary"> 
          <div class="panel-heading"> 
            <h3 class="panel-title">Catatan</h3> 
          </div> 
        <div class="panel-body">
<form method="post" action="./root/proses.php" name="form1" id="form1" onSubmit="return valregister()">
  <div class="table-responsive">
    <table class="table">
     <tr>
      <td style="border-top:none;">
        <textarea class="form-control" placeholder="Isi disini catatan/status untuk ditinggalkan" rows="10" name="note" ></textarea>
      </td>
     </tr>
     <tr>
        <td style="border-top:none;">
          <button type="submit" name="simpan_note" onclick="saveForm(); return false;" class="btn btn-success">
            <img src="lib/galeri/ICON.png" width="30px"></i> Simpan</button>
        </td>
     </tr>
    </table>
  </div>
</form>
<script type="text/javascript">
function valregister(){
            if(form1.note.value==""){
                        alert("Catatan tidak boleh kosong");
                        form1.note.focus();
                        return false;
            } 
             return true; 
}
</script>
<h3 class="text-primary">Catatan Terbaru</h3>
<?php
$status=$db->tampil_Data(0, 3);
?>
      </div> 
    </div>
  </div>
<div class='tab-pane fade' id='stock'>
  <div class="panel panel-primary"> 
          <div class="panel-heading"> 
            <h3 class="panel-title">Stock Barang</h3> 
          </div> 
        <div class="panel-body">
<?php
if(!isset($_SESSION['root'])) {
  error_reporting(0);
?>
<div class="wrapper">
<div class="content-edit-brg"> <!-- /form untuk menampilkan  edit -->
  <span class="label label-danger" style="font-size: 20px;">Edit Data</span>
    <span class="close-form">X</span>
    <form class="form-horizontal" method="post" action="./root/proses.php" name="form1">
        <input type="hidden" name="id_brg" id="pid-nomor" />
          <div class="form-group">
              <label class="col-sm-2 control-label">Kode Barang </label> 
              <div class="col-sm-5">
               <input class="form-control" name="kode" type="text" placeholder="Kode barang" disabled="disabled" id="pid-kode" required> 
              </div> 
          </div>
          <div class="form-group">
              <label class="col-sm-2 control-label">Nama Barang </label> 
              <div class="col-sm-5">
               <input class="form-control" name="nama" id="pid-nama" type="text" placeholder="Nama Barang" required> 
              </div> 
          </div>
          <div class="form-group"> 
            <label class="col-sm-2 control-label">Jenis Barang </label>
            <div class="col-sm-5">
              <select class="form-control" name="jenis"> 
                    <option value="Sembako">Sembako</option> 
                    <option value="Air mineral">Air mineral</option>
              </select>
            </div> 
          </div> 
          <div class="form-group">
              <label class="col-sm-2 control-label">Jumlah Barang </label>
                <div class="col-sm-2">
                  <input type="number" placeholder="Jumlah Barang" id="pid-stok" class="form-control" name="stock" required> 
                </div> 
                <span class="label label-warning" style="font-size: 15px;">Unit / Kardus</span> 
          </div> 
          <div class="form-group"> 
              <label class="col-sm-2 control-label" >Harga Barang</label> 
                <div class="col-sm-5">
                  <input type="number" class="form-control" id="pid-beli" placeholder="Harga Beli Barang" name="harga" required> 
                </div> 
          </div> 
          <div class="form-group"> 
              <label class="col-sm-2 control-label">Harga Jual Barang</label>
                <div class="col-sm-5">
                    <input type="number" class="form-control" id="pid-jual" placeholder="Harga Jual Barang" name="harga_jual" required> 
                </div> 
                  <button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="ubah_brg">
                    <img src="lib/galeri/format.png" width="28px"> Ubah Data</button>
            </div>
    </form>
</div> <!-- /form untuk menampilkan  edit -->
  <a href="#" class="control" data-set="form"><span class="label label-primary" style="font-size: 17px;">Tambah Barang</span></a>
  <div class="form"> <!-- /form untuk menampilkan  tambah -->
      <form class="form-horizontal" method="post" action="./root/proses.php" name="simpan_brg">
          <div class="form-group">
            <label class="col-sm-2 control-label">Kode Barang </label> 
              <div class="col-sm-5">
                <input class="form-control" name="kode" type="text" value="<?php $no_brg=$db->nomor('BADM','kode_brg' ,'barang' );  ?>" /> 
              </div> 
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label">Nama Barang </label> 
              <div class="col-sm-5">
                <input class="form-control" name="nama"  type="text" placeholder="Nama Barang" required> 
              </div> 
          </div> 
          <div class="form-group"> 
            <label class="col-sm-2 control-label">Jenis Barang </label>
              <div class="col-sm-5">
                <select class="form-control" name="jenis"> 
                    <option value="Sembako">Sembako</option> 
                    <option value="Air mineral">Air mineral</option>
                </select>
              </div> 
          </div> 
          <div class="form-group">
            <label class="col-sm-2 control-label">Jumlah Barang </label>
              <div class="col-sm-2">
                <input type="number" placeholder="Jumlah Barang" class="form-control" name="jmlh" required> 
              </div> <span class="label label-warning" style="font-size: 15px;">Unit / Kardus</span> 
          </div> 
          <div class="form-group"> 
            <label class="col-sm-2 control-label" >Harga Barang</label> 
              <div class="col-sm-5">
                <input type="number" class="form-control" placeholder="Harga Beli Barang" name="harga" required> 
              </div> 
          </div> 
          <div class="form-group"> 
              <label class="col-sm-2 control-label">Harga Jual Barang</label>
               <div class="col-sm-5">
                <input type="number" class="form-control" placeholder="Harga Jual Barang" name="total" required> 
            </div> 
            <button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="simpan_brg">
              <img src="lib/galeri/palet.png" width="30px"> Tambah Data</button>
        </div>
    </form>
  </div> <!-- /form untuk menampilkan tamabh  -->
</div>
<?php
} else{
    echo "<h2> Data Stock Barang $tgl1</h2>";
} 
        if (isset($_SESSION['admin'])) {
            echo "<div class='table-responsive'>
            <center><table class='table table-hover' style='width:95%''>
                    <thead><h2>Stock Barang</h2>
                        <tr class='info'>
                            <th>No</th><th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Jenis Barang</th>
                            <th>Stock</th>
                            <th>Harga Beli</th>
                            <th>Harga Jual</th>
                            <th>Tanggal Masuk</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>";
        } else {
            echo"<div class='table-responsive'>
            <center><table class='table table-hover' style='width:95%''>
                    <thead><h2>Stock Barang</h2>
                        <tr class='info'>
                            <th>No</th><th>Kode</th>
                            <th>Nama Barang</th>
                            <th>Jenis Barang</th>
                            <th>Stock</th>
                            <th>Harga Beli</th>
                            <th>Harga Jual</th>
                            <th>Tanggal Masuk</th>
                        </tr>
                    </thead>
                    <tbody>";
        }
$datastock=$db->tampil_stock();
?>
      </div>
  </div>
</div>
<div class="tab-pane fade" id="lap"> 
	<div class="panel panel-primary"> 
			<div class="panel-heading"> 
				<h3 class="panel-title">Laporan</h3> 
			</div> 
				<div class="panel-body">
			<div id='lap-stock' style="width: 78%;"></div>
      <div id='lap-pemasukan' style="width: 78%;"></div>
      <div id='lap-pengeluaran' style="width: 78%;"></div>
				</div> 
	</div> 
</div>
<div class="tab-pane fade" id="transaksi">
  <div class="panel panel-primary"> 
          <div class="panel-heading"> 
            <h3 class="panel-title">Transaksi</h3> 
          </div> 
        <div class="panel-body">
          <div class="panel panel-info">
            <div class="panel-heading">
              <h4 class="panel-title">
              <a data-toggle="collapse" data-parent="#accordion" href="#collapseone"><b>Daftar Rekening</b>
              </a><spam class="pull-right"><a href="" class="label label-primary" data-target="#myModal" data-toggle="modal">
                    <img src="lib/galeri/format.png" width="30px"> Tambah</a></span>
              </h4>
            </div>
          <div id="collapseone" class="panel-collapse collapse">
              <div class="panel-body">
              <?php 
              echo"<div class='table-responsive'>
              <table class='table table-hover'>
                    <thead>
                        <tr class='active'>
                            <th>Bank</th>
                            <th>Nomor Rekening</th>
                            <th>Atas Nama</th>
                            <th>Hapus</th>
                        </tr>
                    </thead>
                    <tbody>";
                $rek= $db->norek();
              ?>
              </div>
          </div>
        </div>
        <h3 class="text-primary" style="text-align: center;"> Transaksi Terbaru <?php $laba=$db->laba_jual(date("m")); ?></h3>
            <?php
              $pesan=$db->tampil_pesanan(" ");
            ?>
          </div>
        </div> 
      </div> 
         <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModallabel" aria-hidden="true">
          <div  class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header" style="background-color: #d00;color: #fff;">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
              <h4 class="modal-title" id="myModalLabel" >
                Rekening
              </h4>
            </div>
            <div class="modal-body">
              <form enctype="multipart/form-data" method="post" action="./root/proses.php" name="form1">
                <div class="form-group"><label class="control-label">Bank</label><span> : </span>
                    <select name="bank" ><option value="">-- PILIH --</option>
                        <option value="BNI">BNI</option>
                        <option value="BRI">BRI</option>
                        <option value="BCA">BCA</option>
                        <option value="MANDIRI">MANDIRI</option></select>
                </div>
                <div class="form-group">
                    <label class="control-label">Nomor Rekening </label> 
                      <input class="form-control" name="nomor" type="text" length="30" placeholder="Isikan Nomor Rekening disini" required> 
                 </div>
                 <div class="form-group">
                    <label class="control-label">Atas Nama </label> 
                     <input class="form-control" name="nama" type="text" length="35" placeholder="Isikan Atas NAma rekening disini" required> 
                 </div>
            </div>
            <div class="modal-footer">
              <button type="submit" name="tambah_rekening" class="btn btn-primary">Simpan</button>
            </div>
            </form>
          </div>
        </div>
  </div>