<?php
class db extends mysqli {    
    private $dbhost  = "localhost";
    private $dbuser = "root";
    private $dbpass = "";
    private $dbname = "koperasi";
     
    public function __construct() {
        parent::__construct($this->dbhost,  $this->dbuser,  $this->dbpass,  $this->dbname);
        if (mysqli_connect_error()) {
            die('Connect Error (' . mysqli_connect_errno() . ') '
                    . mysqli_connect_error());
        }
    }
    public function tampil_Data() {
        $sql = "SELECT*FROM status NATURAL LEFT JOIN pengendali NATURAL LEFT JOIN bulan NATURAL LEFT JOIN day WHERE note='bisa' ORDER BY `id_st` DESC ";
        $query = $this->query($sql);
          
          while ($get_note=$query->fetch_assoc()) {
            $foto = $get_note['foto'];
            $user = "../../$foto";
            $id_note = $get_note['id_st'];
            $id_user = $get_note['id_usr'];
            $bulan = $get_note['bln']; 
            $name = $get_note['status'];
            $jam = $get_note['menit'];
            $hari = $get_note['hari'];
            $note = nl2br(htmlentities($get_note['catatan']));
            $date = $get_note['tgl'];
            $thn = $get_note['tahun'];
            if ($_SESSION['user']) {
                $foto1 = $user;
            } else {
                $foto1 = $foto;
            }
            
              echo  "<div class='message'><h4 style='color: #08b;'><img src='$foto1' width='40px' class='img-circle'> $name
              <span class='pull-right' style='font-size: 15px;color: #000;'>   
                  $jam &bullet; $hari,$date $bulan $thn";
                 if(isset($_SESSION['root'])) {
                    if($id_user==1) {
                         echo "<a href='./root/proses.php?del_status=$id_note' title='Hapus Status' class='menghapus'>
								<img src='lib/galeri/latest.png' width='30px'></a>";
                     }
                 } elseif(isset($_SESSION['admin'])) {
                    if($id_user!=1) {
            echo "
            <a href='./root/proses.php?del_status=$id_note' title='Hapus Status' class='menghapus'><img src='lib/galeri/latest.png' width='30px'></a>";
        }
        }
            echo"</span></div>
            </h4>
                  <div class='alert alert-info' style='border: 1px solid; border-radius: 29px 0px;'><b style='color: #000;'>$note</b></div>";
             
          } 
    }
    public function jmlh($user, $tbl) {
        $sql = "SELECT COUNT(id_usr) as hitung FROM .$tbl WHERE id_usr=".$user."";
        $qry = $this->query($sql);
        $array=$qry->fetch_array();
            $hitung = $array['hitung'];
            echo "$hitung";
    }
    public function laba_jual($cek) {
        $sql ="SELECT sum((a.subtotal)-(b.harga*a.beli)) laba, bln  FROM transaksi a, barang b, detailtransaksi c NATURAL LEFT JOIN bulan 
                WHERE a.kode_brg = b.kode_brg AND a.no_transaksi=c.no_transaksi GROUP BY c.id_bln ORDER BY c.id_bln DESC";
        $query = $this->query($sql);
        $cek = $query->fetch_array();
        $laba = $cek['laba'];
        $bln = $cek['bln'];
        $laba = number_format($laba, 0);
        echo "<span class='pull-right'>Laba pada bulan $bln <code>Rp. $laba</code></span>";
    }
    public function tampil_pesanan($user) {
        $sql = "SELECT*FROM detailtransaksi NATURAL LEFT JOIN pengendali NATURAL LEFT JOIN day NATURAL LEFT JOIN panel 
				NATURAL LEFT JOIN posisi NATURAL LEFT JOIN bulan $user ORDER BY  id_bln DESC , tahun DESC , tgl DESC";
        $query = $this->query($sql);

        while($data = $query->fetch_array()) {
        $no = $data['no_transaksi'];
        $bayar = $data['pembayaran'];
        $metode = $data['metode'];
        $total = $data['total'];
        $posisi = $data['Posisi'];
        $bulan = $data['bln'];
        $tahun = $data['tahun'];
        $hari = $data['hari'];
        $tgl = $data['tgl'];
        $panel = $data['panel'];
        $user = $data['status'];
        $total = number_format($total, 2);
        if($posisi !== "Sukses") {
            if(isset($_SESSION['admin'])) {
                $button = 
                "<button type='button' class='btn btn-danger' onclick=\"window.location.href='./root/proses.php?id=$no&data=batal';\" $disable_in>
                <img src='./lib/galeri/cancel.png' width='20px'> Batal</button>
                <button type='button' class='btn btn-warning' onclick=\"window.location.href='./root/proses.php?id=$no&data=2';\" $disable_in>
                <img src='./lib/galeri/warning-icon.png' width='20px'> Konfirmasi</button>
                <button type='button' class='btn btn-info' onclick=\"window.location.href='./root/proses.php?id=$no&data=3';\" $disable_in>
                <img src='./lib/galeri/handle-2.ico' width='20px'> Sedang dikirim</button></li>
                <button type='button' class='btn btn-info' onclick=\"window.location.href='./root/proses.php?id=$no&data=4';\" $disable_in>
                <img src='./lib/galeri/handle-2.ico' width='20px'> Siap diambil</button>
                <button type='button' class='btn btn-success' onclick=\"window.location.href='./root/proses.php?id=$no&data=5';\" $disable_in>
                <img src='./lib/galeri/sukses.png' width='20px'> Sukses</button>";
        } 
    } else { $button=""; }
echo " <div class='panel panel-$panel' style='width:100%'>
          <div class='panel-heading'>
            <h4 class='panel-title'>
                <a data-toggle='collapse' data-parent='#accordion' href='#collapse$no'><b>$no </b></a> $button
                <span class='pull-right'><span class='label label-$panel'>$posisi</span>  $hari, $tgl $bulan $tahun</span>
            </h4>
          </div>
          <div id='collapse$no' class='panel-collapse collapse'>
        <div class='panel-body'>"; 
        if(!isset($_SESSION['user'])) {
            echo "Nama Pembeli : <strong> $user</strong>"; }
          
          echo"<div class='table-responsive'>
                <table class='table table-striped' style='width:99%'>
                    <thead>
                        <tr class='info'>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Harga</th>
                            <th>Jumlah Beli</th>
                            <th>subtotal</th>
                        </tr>
                    </thead>
                    <tbody>";
            $sql1 = "SELECT*FROM transaksi NATURAL LEFT JOIN barang NATURAL LEFT JOIN waktu WHERE no_transaksi=".$no."";
            $qry = $this->query($sql1);
            while ($file = $qry->fetch_array()) {
                $barang = $file['nama'];
                $kode = $file['kode_brg'];
                $beli = $file['beli'];
                $subtotal = $file['subtotal'];
                $harga = $file['harga_jual'];
                $waktu = $file['waktu'];
                $harga = number_format($harga, 0);
                $subtotal = number_format($subtotal, 0);
                if ($waktu=="") {
                    if (isset($_SESSION['admin'])) {
                        $id =" <form action='./root/proses.php' method='post'> Estimasi waktu : 
                                <input type='hidden' value='$no' name='no_tran'>
                                <input type='text' name='estimasi' placeholder='Contoh : 2 Hari kerja' required />
                                <button type='submit' class='btn btn-warning' name='waktu'>Kirim</button></form>";
                    }
                } else {
                    $id = "Estimasi waktu : <code>$waktu</code>";
                }
            echo "<tr>
				<td>$kode</td>
                <td>$barang</td>
                <td>$harga</td>
                <td>$beli</td> 
                <td>$subtotal</td>
				</tr>";
            } 
            echo "</tbody></table></div>
            Metode Pembayaran : <code>$bayar</code>
            Metode Pengiriman : <code> $metode</code><span class='pull-right'>
            Total : <b style='font-size:17px;border-radius: 6px;background-color: #234;color: #FFF;'> Rp. $total -</b></span>
            $id
            </div>
          </div>
      </div>";
                } 
    }
    public function norek() {
        $sql = "SELECT * FROM rekening NATURAL LEFT JOIN gmbr_rekening";
        $qry = $this->query($sql);

        while ($data = $qry->fetch_array()) {
            $nomor = $data['nomor'];
            $nama = $data['a_nama'];
            $gambar = $data['gambar'];
            if(isset($_SESSION['user'])) {
                echo "<div class='col-md-3 col-sm-6'>
                        <span><img src='../../$gambar' width='85px' class='img-thumbnail'><h4>
                        <div>$nomor </div><div> $nama</div></h4></span></div>";
            } else {
                echo "<tr>
                <td><img src='$gambar' width='70px' class='img-rounded'></td>
                <td> $nomor </td>
                <td> $nama</td>
                <td><a href='./root/proses.php?del_rek=$nomor' title='Hapus $nama'><img src='lib/galeri/delete.png' width='25px'> </a></td>";
            }   // $conn->close();
        } echo "</tr></tbody></table></div>";
    }
   public function brg_jual($tabel) {
        $sql="SELECT * FROM  . $tabel ORDER BY kode_brg ASC";
        $qry=$this->query($sql);
        
        while ($data=$qry->fetch_array()) {
           $kode=$data['kode_brg'];
           $nama=$data['nama'];
           $stok=$data['stock'];
           $harga=$data['harga_jual'];
           $harga_j = number_format($harga);
           if ($stok>=1) {
           
           echo"<div class='col-sm-3'>
           <form class='barang-item'>
           <div class='panel panel-success' style='border-radius: 20px;'> 
                <div class='panel-heading'style='border-radius: 0px 20px;''>$kode 
            </div> 
                <div class='panel-body'><h3>$nama</h3>
                <div class='item-box'>Stock $stok Beli :
            <select name='product_qty'> ";
        
            for ($x=1; $x <= $stok; $x++) {
                    echo "<option value='$x'>$x</option>"; }
                echo "</select>
            </div><br>
                Harga = <b style='font-size: 20px;'>Rp. $harga_j</b>
                <br>
                <input class='btn btn-info' name='product_code' type='hidden' value='$kode'>
            <button class='btn btn-info' type='submit'>BELI</button>
            </div> 
            </div>
            </form>
            </div>";
            } // $conn->close();
        }
    }
    public function tampil_stock() {
        $sql = "SELECT sum((stock*harga_jual) - (stock*harga)) as fee, sum((stock*harga)) as rugi, sum((stock*harga_jual)) as laba FROM barang";
        $total = $this->query($sql);
        $cek = $total->fetch_array();
        $fee = $cek['fee'];
        $rugi = $cek['rugi'];
        $laba = $cek['laba'];
            $fee = number_format($fee);
            $total = number_format($rugi);
            $tot = number_format($laba);
        $ql= "SELECT * FROM  `barang` NATURAL LEFT JOIN bulan ORDER BY  id_bln DESC , thn DESC , hari DESC ";
            $cek_page = $this->query($ql);
                    $no=0;
                    while ($get_user = $cek_page->fetch_array()) {
                        $id = $get_user['id_brg'];
                        $kode = $get_user['kode_brg'];
                        $name = $get_user['nama'];
                        $jenis = $get_user['jenis'];
                        $stock = $get_user['stock'];
                        $bln= $get_user['bln'];
                        $hari = $get_user['thn'];
                        $th = $get_user['hari'];
                        $harga = $get_user['harga'];
                        $harga_j = $get_user['harga_jual'];
                        $harga_b = number_format($harga);
                        $harga_ju = number_format($harga_j);
                        if($stock >= '4') {
                            $panel = '';
                        } else if ($stock == '3') {
                            $panel = '#fae8e3';
                        } else {
                            $panel = '#f2aaa7';
                        }
                        $no++;
                        echo "<tr >
                                <td>$no</td>
                                <td>$kode</td>
                                <td>$name</td>
                                <td>$jenis</td>
                                <td style='background-color: $panel;'>$stock</td>
                                <td>Rp. $harga_b</td>
                                <td>Rp. $harga_ju</td><td>$th $bln $hari</td>";
                            if (isset($_SESSION['admin'])) {
                            echo  "<td> 
                            <a href='#' class='control' data-set='edit-brg' data-nom='$id' data-code='$kode' data-name='$name' data-stok='$stock' data-beli='$harga' data-jual='$harga_j' title='Edit $name'>
                                <img src='lib/galeri/format.png' width='29px'></a>
                                 &bullet; <a href='./root/proses.php?del_brg=$id' class='menghapus' title='Hapus Barang'>
                                <img src='lib/galeri/latest.png' alt='kosong' width='26px'></a>
                                </td>"; } 
                            }

                    echo "</tr></tbody></table></center>
                    <h4>Modal Awal : <b>Rp. $total </b>- \t
                    Total Penjualan : <b>Rp. $tot </b>- \t Keuntungan bersih : <b>Rp. $fee </b> -</h4></div>"; 
                       // $conn->close(); 
    }

    public function data($tbl) {
        $sql= "SELECT * FROM . $tbl  NATURAL LEFT JOIN bulan ORDER BY  id_bln DESC , tahun DESC , tgl DESC ";
        $qry = "SELECT sum(nominal) as laba FROM . $tbl";
        $tampil = $this->query($qry);
        $ext = $tampil->fetch_assoc();
        $laba = $ext['laba'];
        $laba = number_format($laba);    
            $cek_page = $this->query($sql);
        		if ($cek_page->num_rows != 0) {
                    $query_user = $this->query($sql);
                    $no=0;
                    while ($get_user = $query_user->fetch_assoc()) {
                        $id = $get_user['id_masuklain'];
                        $id1 = $get_user['id_keluar'];
                        $kode = $get_user['kode'];
                        $name = $get_user['nama'];
                        $tgl = $get_user['tgl'];
                        $bln = $get_user['bln'];
                        $tahun = $get_user['tahun'];
                        $ket = $get_user['ket'];
                        $jmlh = $get_user['nominal'];
                        $jumlah = number_format($jmlh);
                        $no++; 
                        echo"<tr>
                            <td>$no</td>
                            <td>$kode</td>
                            <td>$name</td>
                            <td>$tgl $bln $tahun</td>
                            <td>Rp. $jumlah</td>
                            <td>$ket</td>";
                    if(isset($_SESSION['admin'])) {
                        if($tbl=='pemasukan_lain') {
                            echo "<td>
                                <a href='#' class='control' data-set='lihat' data-no='$id' data-kode='$kode' data-nama='$name' data-jumlah='$jmlh' data-ket='$ket'
                    title='Edit $name'>
                            <img src='lib/galeri/format.png' width='30px'></a>&bullet;
                    <a href='./root/proses.php?masuk=$id' class='menghapus' title='Hapus $name'><img src='lib/galeri/tr.png' width='27px'></a></td></tr>"; }
                        else {
                            echo "<td>
                                <a href='#' class='control' data-set='edit' data-no='$id1' data-kode='$kode' data-nama='$name' data-jumlah='$jmlh' data-ket='$ket' 						title='Edit $name'>
                                <img src='lib/galeri/format.png' width='30px'></a>&bullet;
                    <a href='./root/proses.php?keluar=$id1' class='menghapus' title='Hapus $name'><img src='lib/galeri/tr.png' width='27px'></a></td></tr>";
                            }
                    } else { }
                    }
                   // $this->close();
                    echo"</tbody><tr></table><b>Total Semua </b></td><td><b>Rp. $laba - </b></center>";
} else {
    echo "<div class='alert alert-danger'><strong>Data masih kosong</strong></div>";
}
    }
        public function nomor($id,$qr,$tabel) {
        $sq = "SELECT max(".$qr.") as kode FROM .$tabel";
        $sql = $this->query($sq);
        $kode = $sql->fetch_array();
        $data = $kode['kode'];

        $urut = (int) substr($data, 6);
        $urut = $urut + 1;
        $newurut = $id.sprintf("%04s", $urut);
        echo $newurut;
    }
    public function pengguna() {
          if (isset($_SESSION['admin'])) {
            $ql="SELECT * FROM  pengendali NATURAL LEFT JOIN detail NATURAL LEFT JOIN bulan ORDER BY `id_usr` ASC";
            echo "<div class='table-responsive'>
            <center><table class='table table-striped' style='width:99%'>
                    <thead>
                        <tr class='info'>
                            <th>No</th>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Aktif Mulai</th>
                            <th>Alamat</th>
                            <th>Level</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $query_user = $this->query($ql);
                    $no=0;
                    while ($get_user = $query_user->fetch_assoc()){
                        $token = $get_user['id_usr'];
                        $name = $get_user['user'];
                        $lv = $get_user['level'];
                        $alamat = $get_user['almt'];
                        $foto = $get_user['foto'];
                        $status = $get_user['status'];
                        $bln = $get_user['bln'];
                        $thn = $get_user['thn'];
                        $no++;
                        echo "<tr>
                                <td>$no</td>
                                <td><img src='$foto' width='70' class='img-responsive'></td>
                                <td>$status</td>
                                <td>$name</td>
                                <td>$bln $thn</td>
                                <td>$alamat</td>
                                <td><b>$lv</b></td>
                                <td><a href='?edit=$token' name='ubah' title='Edit $status'>
                                <img src='lib/galeri/format.png' width='30px'></a> &bullet;  
                                 <a href='?idpwd=$token' title='Edit Katasandi'><img src='lib/galeri/lock.png' width='31px'></a> &bullet;
                                 <a href='./root/proses.php?del_id=$token' class='menghapus' title='Hapus $name'><img src='lib/galeri/latest.png' alt='kosong' width='26px'></a>
                                </td>
                            </tr>";
                    }
                   // $conn->close();
                    echo "</tbody></table></center></div>";
        } elseif(isset($_SESSION['root']) OR isset($_SESSION['user'])){ 
        $ql1="SELECT * FROM  `pengendali` NATURAL LEFT JOIN detail NATURAL LEFT JOIN bulan WHERE id_usr ='$_SESSION[id]'";
                    $query_user1 = $this->query($ql1);
                    $get_user1 = $query_user1->fetch_array();
                     $token = $get_user1['id_usr'];
                        $name = $get_user1['user'];
                        $st = $get_user1['status'];
                        $alamat = $get_user1['almt'];
                        $foto = $get_user1['foto'];
                        $bln = $get_user1['bln'];
                        $thn = $get_user1['thn'];
						if (isset($_SESSION['root'])){
                        echo " <div class='media'> 
                        <a class='pull-left' data-target='#myModal2' data-toggle='modal' href='#'> 
                        <img class='img-thumbnail' src='$foto' maxwidth='400px' width='56%' alt='Media Object'> </a> 
                        <div class='pull-right'>Aktif Sejak $bln - $thn</div>
                        <div class='media-body'> 
                            <h2 class='media-heading'>Profil $st </h2>
                             <h4 style='background-color: #eef;padding: 10px; margin: 10px;'><p>Nama Anda  <div class='col-sm-2'></div>
                             <b><img src='lib/galeri/user.png' width='30px'>  $st</b></p><p>E-mail Anda <div class='col-sm-2'></div>
                            <img src='lib/galeri/email.png' width='30px'> <strong>$name</strong></p><p>Alamat Anda  <div class='col-sm-2'></div>
                            <b><img src='lib/galeri/mapicon.png' width='45px'> $alamat</b></p></h4>
                        </div><a class='btn btn-primary' href='?edit=$token' name='ubah' title='Edit $st'>
                                <img src='lib/galeri/format.png' width='28px'> 
                                 Edit </a> &bullet;  
                                 <a class='btn btn-info' href='?idpwd=$token'>
                                <img src='lib/galeri/lock.png' width='26px'>  Ubah sandi</a></div>";   
                        } else {
                        echo " <center><a href='#' data-target='#myModal1' data-toggle='modal'>
                        <img class='img-thumbnail' src='../../$foto' width='36%' title='Foto profil'>
                        </a></center>
                        <div class='pull-right'>Aktif Sejak $bln - $thn</div> 
                            <h2>Profil $st</h2>
                             <h4 style='background-color: #eef;padding: 10px; margin: 10px;'><p>Nama Anda  
                             <div class='col-sm-2'></div>
                             <b><img src='../../lib/galeri/user.png' width='40px'> $st</b></p>
                             <p>E-mail Anda <div class='col-sm-2'></div>
                            <img src='../../lib/galeri/email.png' width='37px'> 
                            <strong>$name</strong></p><p>Alamat Anda  <div class='col-sm-2'></div>
                            <b><img src='../../lib/galeri/mapicon.png' width='52px'> $alamat</b></p></h4>";  
						}
                    }    
            }
}
?>
