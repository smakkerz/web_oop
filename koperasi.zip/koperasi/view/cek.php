<!DOCTYPE html>

<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><s!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>Koperasi-ADM</title>
	<link rel="shorcut icon" href="lib/galeri/kop.jpg" />

	<link href="lib/asset/css/bootstrap.css" rel="stylesheet" type="text/css" />

	<script type="text/javascript" src="lib/asset/js/jquery.min.js"></script>
	<script type="text/javascript" src="lib/asset/js/bootstrap.js"></script>

</head>
<body>
<div class="container-fluid" >
	<?php include "lib/jam.php"; ?>
		<div class="col-sm-8 offset">
			<div class="row">
				<form class="form-signin" name="masuk" role="form" method="post" action="root/proses.php">
					<h4 class="form-signin-heading" >
						<img src="lib/galeri/icon-dashboard.png" width="38px"> Masuk Dashboard</h4>
<?php
if (isset($_GET['log'])) {
            echo "<div class='alert alert-danger'>
            <strong><img src='lib/galeri/warning-icon.png' width='24px'> E-mail / Sandi salah, Isi dengan benar</strong></div>";
} 
?>
					<div class="input-group">
						<input type="email" class="form-control" name="user" placeholder="Username / E-mail" required />
							<span class="input-group-addon"><img src="lib/galeri/email-2-icon.png" width="25px"></span></div><br>
					<div class="input-group">
						<input type="password" class="form-control" id="pass" name="pass" placeholder="Password / Sandi" required />
							<span class="input-group-addon"><img src="lib/galeri/lock.png" width="25px"></span></div><br>
					<button type="submit" name="login" class="btn btn-danger">
						<img src="lib/galeri/user.png" width="26px"> Masuk </button><span class="pull-right">
						<h4><a href="" data-target="#myModal6" data-toggle="modal" > Alamat Koperasi</a></h4></span>
				</form>
				<span class="pull-right well"> Bagi yang ingin mendaftar menjadi pengguna Silahkan Hubungi Admin   
						<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Persyaratan</a>
					<div id="collapse3" class="panel-collapse collapse">
						<div class="panel-body" style="background-color: #d02;color: #fff;">
							<h4><b>Persyaratan untuk menjadi anggota koperasi</b></h4>
							<ul>
								<li> Fotocopy KTP/Kartu Indentitas  2 lembar </li>
								<li> Foto Warna 3x4  2 lembar </li>
								<li> Membayar Rp 10,000 - (untuk kas) dan Mengisi formulir yang telah disediakan oleh Teller/Admin </li>
							</ul>
						</div>
					</div>
				</span>
				</div>
			</div>
		</div>
		<div class="modal fade" id="myModal6" tabindex="0" role="dialog" aria-labelledby="myModallabel" aria-hidden="true">
          <div  class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header" style="background-color: #d00;color: #fff;">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
              <h4 class="modal-title" id="myModalLabel" >
                ALAMAT KOPERASI
              </h4>
            </div>
            <div class="modal-body">
            	<h2><img src="lib/galeri/kop.jpg" width="80px"> Alamat Koperasi Amanah Daarul Muttaqin</h2><hr>
            	<p>Jalan Sidomukti Raya RT 06 RW 18 (Samping Masjid Daarul Muttaqin) kelurahan Muktiharjo 
            	Kidul kecamatan Pedurungan, Semarang Jawa Tengah</p>
            	<iframe src="https://www.google.com/maps/d/embed?mid=1gLk6c4LaKwK3atINOYfpt4ljb7c" width="550px" height="500px"></iframe>
            </div>
          </div>
        </div>
</body>
</html>