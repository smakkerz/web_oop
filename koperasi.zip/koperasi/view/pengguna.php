<div class="tab-pane fade" id="pengguna" >
	<div class="panel panel-primary"> 
		<div class="panel-heading"> 
			<h3 class="panel-title"> 
      <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Pengguna</a></h3> 
		</div> 
    <div id="collapse3" class="panel-collapse collapse in">
		  <div class="panel-body">
        <?php
          $data_pengguna=$db->pengguna();
  
          if(isset($_GET['edit'])) {
          $id = mysqli_real_escape_string($conn, $_GET['edit']);
          $sql_d = "SELECT*FROM pengendali WHERE id_usr='$id'";
          $get_sw = $conn->query($sql_d)->fetch_assoc();
          extract($get_sw);
        ?>
       <h2><span class="label label-primary">Ubah Data Pengguna</span></h2>
        <form class="form-horizontal" method="post" action="./root/proses.php" name="form1" id="form1" onSubmit="return valregister()">
           <input type="hidden" name="id_user" value="<?php echo $id_usr; ?>" />
          <div class="form-group">
              <label class="col-sm-2 control-label">Nama User</label> 
              <div class="col-sm-5">
                <input class="form-control" name="nama" type="text" value="<?php echo $status;?>" placeholder="Kode barang" required> 
              </div> 
          </div>
          <div class="form-group">
              <label class="col-sm-2 control-label">Username</label> 
                <div class="col-sm-5">
                  <input class="form-control" name="email" value="<?php echo $user; ?>" type="email" placeholder="Nama Barang" required> 
                </div> 
          </div> 
          <div class="form-group">
              <label class="col-sm-2 control-label">Alamat</label>
              <div class="col-sm-6">
                <input type="text" placeholder="Jumlah Barang" value="<?php echo $almt; ?>" class="form-control" name="alamat" required> 
              </div>
                <button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="ubah">
                <img src="./lib/galeri/format.png" width="28px"> Ubah Data</button>
              </div>
        </form>
        <?php } else { }
          if(isset($_GET['idpwd'])) {
          $id = mysqli_real_escape_string($conn, $_GET['idpwd']);
          $sql_d = "SELECT*FROM pengendali WHERE id_usr='$id'";
          $get_sw = $conn->query($sql_d)->fetch_assoc();
          extract($get_sw); { ?>
          <h2><span class="label label-primary">Ubah Sandi <?php echo"$nama";?></span></h2>
          <form class="form-horizontal" method="post" action="./root/proses.php" name="form1" id="form1" onSubmit="return valregister()">
              <input type="hidden" name="id_user" value="<?php echo $id_usr; ?>" />
              <div class="form-group">
                <label class="col-sm-2 control-label">Kata sandi Baru</label> 
                <div class="col-sm-4">
                    <input class="form-control" name="sandi" type="password" placeholder="Kata sandi baru" required> 
                </div> 
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">Verifikasi</label>
                <div class="col-sm-4">
                  <input type="password" placeholder="Verifikasi Kata sandi" class="form-control" name="sandi1" required> 
                </div>
                <button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="ubah_sandi">
                <img src="./lib/galeri/format.png" width="28px"> Ubah Data</button>
              </div>
          </form>
        <?php } 
        } ?> 
          </div>
      </div> 
  </div>
  <?php
  if (isset($_SESSION['admin'])) {
  ?>
      <div class="panel panel-info">
          <div class="panel-heading">
            <h4 class="panel-title">
            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2"><b>Tambah Pengguna</b>
            </a>
            </h4>
          </div>
          <div id="collapse2" class="panel-collapse collapse">
            <div class="panel-body">
              <form method="post" class="form-horizontal" action="./root/proses.php">
                  <div class="form-group">
                    <label class="col-sm-2 control-panel">Nama</label>
                    <div class="col-sm-4">
                        <input type="text" class="form-control" maxlength="30" name="nama" placeholder="Isi Nama" required />
                    </div>
                    <label class=" col-sm-2 control-panel">Kata Sandi</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" maxlength="25" name="sanid" placeholder="Isi Password" required />
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2">Username / E-mail</label>
                    <span class="col-sm-4">
                        <input type="email" class="form-control" name="email" placeholder="Isi Username" required />
                    </span>
                    <label class="col-sm-2">Level</label>
                    <span class="col-sm-3"><select name="level"><option>user</option>
                        <option>admin</option>
                        <option>root</option></select></span>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-2">Alamat</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="alamat" rows="3" placeholder="Isi Alamat" required /></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                      <button type="submit" class="btn btn-primary" onclick="saveForm(); return false;" name="anggota">
                      <img src="./lib/galeri/add-user.png" width="28px"> Tambah Pengguna</button>
                  </div>
              </form>
            </div>
          </div>
      </div>
        <?php } ?>
</div>

<div class="tab-pane fade" id="petunjuk">
    <center><h3>Petunjuk Penggunaan Dashboard Koperasi Amanah Daarul Muttaqin</h3></center>
    <nav class="navbar" role="navigation"> 
  <div class="Alert alert-info"> 
    <ul class="pager"> <h4>
      <li class="info"><a href="#book-transaksi"><img src="./lib/galeri/tran.png" width="25px"> Transaksi</a></li>
      <li class="active"><a href="#book-catatan"><img src="./lib/galeri/User-Group.png" width="25px">  Catatan</a></li>
      <li class="active"><a href="#book-pemasukan"><img src="./lib/galeri/cal.png" width="25px">  Pemasukan</a></li> 
      <li class="active"><a href="#book-pengeluaran"><img src="./lib/galeri/cart-icon.png" width="25px">  Pengeluaran</a></li> 
      <li class="active"><a href="#book-stock"><img src="./lib/galeri/palet.png" width="25px">  Stock Barang</a></li>
      <li class="active"><a href="#book-pengguna"><img src="./lib/galeri/user.png" width="25px">  Pengguna</a></li> 
      <li class="active"><a href="#book-laporan"><img src="./lib/galeri/book.png" width="25px">  Laporan</a></li> 
      </h4>
    </ul> 
  </div> 
   </nav>
   <blockquote><h3>Petunjuk Umum</h3></blockquote>
   <p class="lead">Dashboard Koperasi Amanah Daarul Muttaqin digunakan untuk mempermudah kegiatan jual-beli yang ada di koperasi dan pada halaman 
    pada bagian ini digunakan untuk menjelaskan/ memberitahukan tentang penggunaan/tata cara pada dashboard koperasi amanah daarul muttaqin
    yang digunakan untuk mengolah data tentang sistem informasi penjualan barang koperasi dan lain-lain yang berkaitan.<br>
    Berikut penjelasan dasar tentang penggunaan gambar/icon sebagai berikut : </p>
    <ol>
    <li><img src="./lib/galeri/format.png" width="28px"> sebuah icon/tombol untuk merubah/mengolah data yang dipilih</li>
    <li><img src="./lib/galeri/tr.png" width="20px"> &bullet; <img src="./lib/galeri/latest.png" width="20px"> sebuah icon/tombol untuk menghapus data yang dipilih</li>
    <li><img src="./lib/galeri/lock.png" width="20px"> sebuah icon/tombol untuk mengolah data yang rahasia seperti katasandi.</li>
    <li><img src="./lib/galeri/calendar-128.png" width="20px"> sebuah icon/tombol untuk melihat tanggal</li>
    <li><img src="./lib/galeri/clock.png" width="20px"> sebuah icon/tombol untuk melihat waktu</li>
  </ol>
  <p class="lead">Pada dashboard ini terdapat batasan-batasan atau masih jauh dari sempurna, dashboard ini sementara hanya melayani jual-beli tanpa
    ada member costumer dan data supplier dan belum melayani simpan pinjam seperti di koperasi pada umumnya.
  </p>
<div class="section"> 
    <h4 id="book-transaksi"><p class="text-info"><img src="./lib/galeri/tran.png" width="28px">Transaksi</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">Pada bagian Transaksi hanya akan ditampilkan penjualan barang yang terjual. Dan untuk <B>ADMIN</B> pada bagian
        ini digunakan untuk membuat rekap laba, total penjualan, total barang terjual, dan akan menghitung pemasukan dari hasil penjualan ini
        serta menginputkan pemasukan laba. Berbeda bagi <B>ROOT</b> atau ketua koperasi pada bagian ini sebagai bahan pertimbangan untuk
        menyusun rencana atau strategi dalam pembelian stock barang yang banyak dicari.</p>
      </div> 
      </div> 
  </div>
  <div class="section"> 
    <h4 id="book-catatan"><p class="text-info"><img src="./lib/galeri/User-Group.png" width="28px">Catatan</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">Pada bagian Catatan/status diperuntukkan untuk mempermudah komunikasi atau memberitahukan 
        atau bisa juga untuk memberikan rencana kedepan.<p><ol><li>Silahkan klik pada <b>Status</b> yang terletak pada sidebar kiri layar.</li>
        <li> Kemudian isi textarea yang sudah disediakan.</li><li> Jika sudah selesai klik tombol <b>simpan</b> yang ada dibawah textarea.</li></ol></p>
      </div> 
      </div> 
  </div>
  <div class="section"> 
    <h4 id="book-pemasukan"><p class="text-info"><img src="./lib/galeri/cal.png" width="28px">Pemasukan</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">Untuk bagian Pemasukan hanya bisa diisi oleh <b>ADMIN</b>. Dikarenakan koperasi melayani berbagai pelayanan
        dari simpan-pinjam, pembayaran listrik, pembayaran PDAM, hingga menjual Sembako dan air mineral<br>
        <p class="text-danger">Pemasukan digunakan untuk mengelola sumber dana yang didapatkan koperasi selain dari penjualan barang
		sesuai dengan jasa yang ditawarkan dikoperasi.<br> Jadi secara matematika dasar 25% 
           melihat dan mendengarkan + 25% memahami + 20% praktek + 25% membagikan maka hasilnya terbilang sangat 
           luarbiasa dan ilmu yang bermanfaat adalah ilmu yang berguna dan mengalir.</p>
      </div> 
      </div> 
  </div>
  <div class="section"> 
    <h4 id="book-pengeluaran"><p class="text-info"><img src="./lib/galeri/cart-icon.png" width="28px">Pengeluaran</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">Pengeluaran digunakan untuk mengelola dana yang digunakan dalam kebutuhan oprasional koperasi seperti : 
        Untuk membayar gaji karyawan, untuk membayar listrik yang dipakai koperasi, dan lain-lain.<br>
        <p class="text-danger">ADMIN<br>
          ADMIN diharapkan untuk mengisi pada form yang tersedia sesuai dengan tugasnya. <br> Pada form terdapat <b>Kode pengeluaran</b>, 
          <b>Nama/jenis pengeluaran</b>, <b>Keterangan</b>, <b>Jumlah</b> yang wajib diisi dan jika telah selesai silahkan KLIK tombol <b>TAMBAHKAN</b>.
          ADMIN juga berhak untuk merubah bila ada kesalahan waktu menambahkan data dan juga berhak menghapus bila tidak sesuai/telah selesai</p>
          <p>Untuk ROOT/KETUA cukup mengawasi data yang diisi oleh ADMIN</p>
      </div> 
      </div> 
  </div>
    <div class="section"> 
    <h4 id="book-stock"><p class="text-info"><img src="./lib/galeri/palet.png" width="28px">Stock</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">KOPERASI-ADM adalah sebuah singkatan koperasi Amanah Da'arul Muttaqin merupakan sebuah koperasi 
        yang berada di sidomukti tlogosari semarang yang dibentuk guna memberdayakan masyarakat yang berada lingkungan
        sekitar sidomukti.</br> Semoga berguna bagi teman-teman<br>
        <p class="text-danger">Kenapa penulis ingin membagikan ilmunya ??<br>
          Karena mungkin bagi para psikologi atau bagi motivator tahu daya ingat manusia untuk menerima informasi atau 
          ilmu hanya sekitar 25%-45% menerima dalam bentuk pendengaran dan melihat. Jika memahami mungkin akan bertambah 
          sekitar 25% dan jika mengimmplementasikan akan bertambah sekitar 20% selanjutnya jika tambah dengan membagikan
           minimal 5 orang atau lebih akan bisa meningkat sekitar 25% bisa lebih.<br> Jadi secara matematika dasar 25% 
           melihat dan mendengarkan + 25% memahami + 20% praktek + 25% membagikan maka hasilnya terbilang sangat 
           luarbiasa dan ilmu yang bermanfaat adalah ilmu yang berguna dan mengalir.</p>
      </div> 
      </div> 
  </div>
  <div class="section"> 
    <h4 id="book-pengguna"><p class="text-info"><img src="./lib/galeri/user.png" width="28px">Pengguna</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">KOPERASI-ADM adalah sebuah singkatan koperasi Amanah Da'arul Muttaqin merupakan sebuah koperasi 
        yang berada di sidomukti tlogosari semarang yang dibentuk guna memberdayakan masyarakat yang berada lingkungan
        sekitar sidomukti.</br> Semoga berguna bagi teman-teman<br>
        <p class="text-danger">Kenapa penulis ingin membagikan ilmunya ??<br>
          Karena mungkin bagi para psikologi atau bagi motivator tahu daya ingat manusia untuk menerima informasi atau 
          ilmu hanya sekitar 25%-45% menerima dalam bentuk pendengaran dan melihat. Jika memahami mungkin akan bertambah 
          sekitar 25% dan jika mengimmplementasikan akan bertambah sekitar 20% selanjutnya jika tambah dengan membagikan
           minimal 5 orang atau lebih akan bisa meningkat sekitar 25% bisa lebih.<br> Jadi secara matematika dasar 25% 
           melihat dan mendengarkan + 25% memahami + 20% praktek + 25% membagikan maka hasilnya terbilang sangat 
           luarbiasa dan ilmu yang bermanfaat adalah ilmu yang berguna dan mengalir.</p>
      </div> 
      </div> 
  </div>
  <div class="section"> 
    <h4 id="book-laporan"><p class="text-info"><img src="./lib/galeri/book.png" width="28px">Laporan</p></h4>
      <div class="panel panel-primary"> 
        <div class="panel-heading"> 
          <h3 class="panel-title">INFORMASI</h3> 
        </div> 
      <div class="panel-body">KOPERASI-ADM adalah sebuah singkatan koperasi Amanah Da'arul Muttaqin merupakan sebuah koperasi 
        yang berada di sidomukti tlogosari semarang yang dibentuk guna memberdayakan masyarakat yang berada lingkungan
        sekitar sidomukti.</br> Semoga berguna bagi teman-teman<br>
        <p class="text-danger">Kenapa penulis ingin membagikan ilmunya ??<br>
          Karena mungkin bagi para psikologi atau bagi motivator tahu daya ingat manusia untuk menerima informasi atau 
          ilmu hanya sekitar 25%-45% menerima dalam bentuk pendengaran dan melihat. Jika memahami mungkin akan bertambah 
          sekitar 25% dan jika mengimmplementasikan akan bertambah sekitar 20% selanjutnya jika tambah dengan membagikan
           minimal 5 orang atau lebih akan bisa meningkat sekitar 25% bisa lebih.<br> Jadi secara matematika dasar 25% 
           melihat dan mendengarkan + 25% memahami + 20% praktek + 25% membagikan maka hasilnya terbilang sangat 
           luarbiasa dan ilmu yang bermanfaat adalah ilmu yang berguna dan mengalir.</p>
      </div> 
      </div> 
  </div>

</div>