<?php
include_once "function.php";
include_once "lib/jam.php";
$db = new db();

  if(!isset($_SESSION['user'])){
    $sql = "SELECT*FROM pengendali WHERE id_usr='$_SESSION[id]'";
      $query = $db->query($sql);
    $get_user=$query->fetch_assoc();
    $name = $get_user['status'];
    $foto = $get_user['foto'];
  }else{
    header("Location: view/adm/admin.php");
  }

?>
<!DOCTYPE html><html lang="en">
<head>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
	<title>Koperasi Amanah Daarul Muttaqin</title>
	<link rel="shorcut icon" href="./lib/galeri/kop.jpg" />

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no' name='viewport'>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	
  <link rel="stylesheet" href="lib/asset/css/bootstrap1.css" />

	<script type="text/javascript" src="lib/asset/js/jquery.min.js"></script>
	<script type="text/javascript" src="lib/asset/js/bootstrap.js"></script>
	<script src="lib/asset/js/highcharts.js" type="text/javascript"></script>
  <script src="lib/asset/js/data.js" type="text/javascript"></script>
	<style type="text/css">
.wrapper { margin: none; }
.wrapper .content-form { display: none; }
.wrapper .content-view { display: none; }
.wrapper .content-edit { display: none; }
.wrapper .content-edit-brg { display: none; }
.close-form { float: right; margin-right: 5px; cursor: pointer; }
  </style>
  <script type="text/javascript">
    $(function() { 
  //Banrang
  var chart1; // globally available
$(document).ready(function() {
      chart1 = new Highcharts.Chart({
         chart: {
            renderTo: 'lap-stock',
            type: 'column'
         },   
         title: {
            text: 'Keuntungan Penjualan tiap bulan dalam bentuk Grafik '
         },
        subtitle: {
          text: 'KOPERASI AMANAH DAARUL MUTTAQIN'
         },
         xAxis: {
            categories: ['Pada Bulan']
         },
         yAxis: {
            title: {
               text: 'Keuntungan Penjualan'
            }
         },
              series:             
            [
            <?php                     
              $sql = "SELECT sum((a.subtotal)-(b.harga*a.beli)) laba, bln  FROM transaksi a, barang b, detailtransaksi c NATURAL LEFT JOIN bulan 
                WHERE a.kode_brg = b.kode_brg AND a.no_transaksi=c.no_transaksi GROUP BY c.id_bln";
                 $jmlh = $db->query($sql);        
                 while($data = $jmlh->fetch_assoc()) {
                    $jumlah = $data['laba'] ;
                    $bln = $data['bln'];                 
                  ?>
                  {
                      name: '<?php echo $bln; ?>',
                      data: [<?php echo $jumlah; ?>]
                  },
                  <?php } ?>
            ]
      });
   });  
//Pemasukan
  var chart2; // globally available
$(document).ready(function() {
      chart2 = new Highcharts.Chart({
         chart: {
            renderTo: 'lap-pemasukan',
            defaultSeriesType: 'column'
         },   
         title: {
            text: 'Pemasukan tiap bulan dam bentuk grafik '
         },
        subtitle: {
          text: 'KOPERASI AMANAH DAARUL MUTTAQIN'
         },
         xAxis: {
            categories: ['Pada Bulan']
         },
         yAxis: {
          min: 0,
            title: {
               text: 'Nominal (Rp.)'
            }
         },
         legend: {
          layout: 'vertical',
          align: 'left',
          verticalAlign: 'top',
          x: 70,
          y: 70,
          floating: true,
          shadow: true
         },

              series:             
            [
            <?php 

           $sql   = "SELECT id_bln, bln, nama FROM pemasukan_lain NATURAL JOIN bulan GROUP BY id_bln";
           $why = $db->query($sql);
           while ($ret = $why->fetch_array()) { 
              $merek=$ret['id_bln'];
              $loca=$ret['bln'];                     
                 $sql_jumlah   = "SELECT sum(nominal) as total FROM pemasukan_lain WHERE id_bln='$merek'";
                 $jmlh = $db->query($sql_jumlah);      
                 $data = $jmlh->fetch_array(); 
                    $jumlah = $data['total'];                 
                           
                  ?>
                  {
                      name: '<?php echo $loca; ?>',
                      data: [<?php echo $jumlah; ?>]
                  },
                  <?php } ?>
            ]
      });
   });  
//Pengeluaran
 var chart2; // globally available
$(document).ready(function() {
      chart2 = new Highcharts.Chart({
         chart: {
            renderTo: 'lap-pengeluaran',
            type: 'column'
         },   
         title: {
            text: 'Pengeluaran tiap bulan dam bentuk grafik '
         },
         subtitle: {
          text: 'KOPERASI AMANAH DAARUL MUTTAQIN'
         },
         xAxis: {
            categories: ['Bulan']
         },
         yAxis: {
          min: 0,
            title: {
               text: 'Nominal (Rp.)'
            }
         },
         legend: {
          layout: 'vertical',
          align: 'left',
          verticalAlign: 'top',
          x: 70,
          y: 70,
          floating: true,
          shadow: true
         },
          tooltip: {
            backgroundColor: '#FCFCDA',
            borderColor: 'blue',
            borderRadius: 10,
            borderWidth: 3
            },
              series:             
            [
            <?php 

           $sql   = "SELECT id_bln, bln FROM pengeluaran NATURAL JOIN bulan group by id_bln";
           $why = $db->query($sql);
           while ($ret = $why->fetch_assoc()) { 
              $merek=$ret['id_bln'];
              $loca=$ret['bln'];                     
                 $sql_jumlah   = "SELECT sum(nominal) as total FROM pengeluaran WHERE id_bln='$merek'";
                 $jmlh = $db->query($sql_jumlah);      
                 $data = $jmlh->fetch_assoc(); 
                    $jumlah = $data['total'];                 
                           
                  ?>
                  {
                      name: '<?php echo $loca; ?>',
                      data: [<?php echo $jumlah; ?>]
                  },
                  <?php } ?>
            ]
      });
   }); 

});
</script>
</head>
<body>
<div class="container-fluid">
    <div class="navbar navbar-fixed-top">
	     <div class="row" style="background: -webkit-linear-gradient(38deg, #d02, #f9a); background-color: #d01; ">
		    <h3 style="margin: 2px 2px; padding: 10px 20px ; ">
			     <span style="color: #fff;"> DASHBOARD KOPERASI AMANAH DA'ARUL MUTTAQIN   
				      <i class="pull-right">
					       <a href="view/logout.php" class="btn btn-primary">
					         <img src="lib/galeri/off.png" width="20px"> Keluar</a>
				      </i>
			       </span>
		    </h3>
	     </div>
    </div>
  <hr>
  <br>
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <?php 
          include 'root/model/sidebar.php';
          ?>  
        </div>
        <div class="col-sm-9 col-md-10 well">
          <?php 
          include 'root/model/isi.php';
          ?>
        </div>
     </div>
     	<?php include 'lib/footer.php'; ?>
</div>
<textarea id="printing-css" style="display:none;">.no-print{display:none;}</textarea>
<textarea id="printing" style="display:none;">  ||  SIP.Koperasi@ADM.com @ Sistem Informasi Penjualan (Smakkerz)</textarea>
<iframe id="printing-frame" name="print_frame" src="about:blank" style="display:none;"></iframe>
<script type="text/javascript">
function printDiv(elementId) {
 var a = document.getElementById('printing-css').value;
 var b = document.getElementById(elementId).innerHTML;
 var c = document.getElementById('printing').value;
 window.frames["print_frame"].document.title = document.title + c;
 window.frames["print_frame"].document.body.innerHTML = '<style>' + a + '</style>' + b ;
 window.frames["print_frame"].window.focus();
 window.frames["print_frame"].window.print();
}
</script>
</body>
</html>
