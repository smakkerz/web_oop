<?php
include "../function.php";
$db = new db();

  $no = $_POST['rekening'];
  $id = mysqli_real_escape_string($db, $no);
  $sql_d = "SELECT * FROM rekening WHERE nomor='$no'";
  $get_sw = $db->query($sql_d)->fetch_assoc();
    extract($get_sw);
    echo $nomor;
?>
<form class="form-horizontal" method="post" action="./root/proses.php" name="form1">
  <input type="hidden" name="id_brg" value="<?php echo $id_brg; ?>" />
    <div class="form-group">
        <label class="col-sm-2 control-label">Kode Barang </label> 
        <div class="col-sm-5">
         <input class="form-control" name="kode" type="number" value="<?php echo $nomor; ?>" placeholder="Kode barang" disabled="disabled" required> 
     </div> 
 </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Nama Barang </label> 
        <div class="col-sm-5">
         <input class="form-control" name="nama" value="<?php echo $a_nama; ?>" type="text" placeholder="Nama Barang" required> 
     </div> 
 </div>
</form>