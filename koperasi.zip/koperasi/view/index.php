<?php
session_start();
include "lib/db.php";
	if(isset($_SESSION['user'])){
		$user = $_SESSION['user'];
	}else{
		header("Location: ../manual/index.php");
	}
?>
<!DOCTYPE html>

<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6 lt8"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7 lt8"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8 lt8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><s!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
	<meta charset="utf-8">
	<title>4(Sekawan)-PRIBADI</title>
	<link rel="icon" href="4.jpg" />
	<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.2 -->
	<meta name="description" content="website pribadi smakkerz yang berisi programmer">
	<meta name="author" content="@SMAKKERZ">
	<meta name="">
	<link rel="shortcut icon" href="favicon.png"/>
	<link href="lib/asset/css/bootstrap1.min.css" rel="stylesheet" type="text/css"/>

	
	<script type="text/javascript" src="lib/asset/js/jquery.min.js"></script>
	<script type="text/javascript" src="ib/asset/js/bootstrap.min.js"></script>
</script>
</head>
<body>
<div class="navbar navbar-static-top">
	<div class="navbar-inner">
		<div class="row">
			<div class="container">
				<div class="col-sm-3 col-md-6 col-lg-4">
					<a href="?refresh" class="brand" ><p class="icon-refresh"></p>
						<img src="lib/galeri/kop.jpg" class="img-circle" width="50px">
							KOPERASI ADM<p><b>For Dekstop/PC</b></p></a>
					<div class="col-sm-9 col-md-6 col-lg-8">
						<div class="text-right">
							<div class="navbar-brand">Hidup harus bermakna dan bermanfaat karna hidup 
							didunia ini tidaklah kekal. 
							</div>
							<a href="?log=0" class="btn btn-primary">
								<i class="icon-user"></i>KELUAR</a>
						</div>
					</div>
				</div>	
			</div>
		</div>
	</div>
</div>
<div class="container">
	<div class="row">
		<h3><img src="lib/galeri/kop.jpg" class="img-rounded" width="105px"> Selamat Datang Di Sistem Koperasi Amanah Da'arul Muttaqin </h3>
		<hr>
	</div>
	<div class="text-center">
		<div class="btn-toolbar" role="toolbar">
			<div class="btn-group">
				<ul id="myTab" class="nav nav-tabs">
					<li><a href="#smakkerz" class="btn btn-success" data-toggle="tab" data-target="#smakkerz">
						<i class="icon-home"></i>STOCK</a></li>
					<li><a href="#materi" class="btn btn-danger" data-toggle="tab" data-target="#materi">
						<i class="icon-file"></i>TRANSAKSI</a></li>
					<li><a href="#galeri" class="btn btn-warning" data-toggle="tab" data-target="#galeri">
						<i class="icon-envelope"></i>STATUS</a></li>
					<li><a href="#" class="btn btn-info" data-toggle="modal" data-target="#myModal">
					<i class="icon-info-sign"></i>Info</a></li>
					<li>
					</li>
				</ul>
				
			</div>
		</div>
		<div class="dropdown">
<button type="button" class="btn btn-primary dropdown-toggle" id="dropdownMenu1"
data-toggle="dropdown"><div class="icon-list-ol"></div>
Menu
<span class="caret"></span>
</button>
<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
<li role="presentation" class="dropdown-header">Favorit</li>
<li role="presentation" >
<a role="menuitem" tabindex="-1" href="#">PHP</a>
</li>
<li role="presentation">
<a role="menuitem" tabindex="-1" href="#">HTML, CSS(BOOTSTRAP)</a>
</li>
<li role="presentation">
<a role="menuitem" tabindex="-1" href="#">MYSQL-i</a>
</li>
<li role="presentation">
<a role="menuitem" tabindex="-1" href="#">AJAX</a>
</li>
<li role="presentation">
<a role="menuitem" tabindex="-1" href="#">JAVA</a>
</li>
<li role="presentation">
<a role="menuitem" tabindex="-1" href="#">OLAHRAGA</a>
</li>
<li role="presentation" class="divider"></li>
<li role="presentation" class="dropdown-header">BONUS</li>
<li role="presentation">
<a role="menuitem" tabindex="-1" href="#">AGAMA</a>
<a role="menuitem" tabindex="-1" href="#">VB.NET</a>
<a role="menuitem" tabindex="-1" href="#">WISATA/SEMARANG</a>
</li>
</ul>
</div>
		<?php require "menu.php"; ?>
		
	</div>
</div>
<script>
$(function() { 
	$(window).scroll(function() { 
		if($(this).scrollTop()>100) { $('#ScrollToTop').fadeIn()} 
			else { $
				('#ScrollToTop').fadeOut();}});
$('#ScrollToTop').click(function(){$('html,body').animate({scrollTop:0},1000);return false})});
</script>
<a style="display:scroll;position:fixed;bottom:5px;right:5px;" href='javascript:void(0);' 
		onclick='jQuery(&apos;html, body&apos;).animate({scrollTop:0}, &apos;slow&apos;);' 
		title="Kembali ke atas">
			<img src="img/back-to-top1.png" /></a>
<hr>
<div class="footer-bottom">
	<div class="col-md-6" style="background-color: #dedddd;">
		<div class="container">
			<p class="pull-left"> &copy; SMAKKERZ v1.62 &middot; 2016 </p>
			<p class="pull-right">E-mail : yusufadhi77@gmail.com / yusufadhi7@ymail.com 
					<a href="admin/login.php" class="btn btn-default">
					<i class="icon-hdd"></i> Login</a></p>
		</div>
	</div>
</div>
</body>
<script src="js/jquery-2.1.4.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>
